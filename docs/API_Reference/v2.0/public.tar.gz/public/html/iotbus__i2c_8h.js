var iotbus__i2c_8h =
[
    [ "iotbus_i2c_context_h", "group___i2_c.html#ga134ba93f2558d6ba3cac64386064addd", null ],
    [ "iotbus_i2c_mode_e", "group___i2_c.html#gaf9e314e7139fe7125419a2f29ff51ae2", [
      [ "IOTBUS_I2C_STD", "group___i2_c.html#ggaf9e314e7139fe7125419a2f29ff51ae2ae655c2c9d9b01c9c0f348152f2d49f37", null ],
      [ "IOTBUS_I2C_FAST", "group___i2_c.html#ggaf9e314e7139fe7125419a2f29ff51ae2a5163354e685ef8625727ecb866d15eec", null ],
      [ "IOTBUS_I2C_HIGH", "group___i2_c.html#ggaf9e314e7139fe7125419a2f29ff51ae2a2d13c72d1e8d4cbcaa87b34f6f85ede6", null ]
    ] ],
    [ "iotbus_i2c_init", "group___i2_c.html#ga158bef1ca0d3550bc08b9846d17f31dd", null ],
    [ "iotbus_i2c_read", "group___i2_c.html#ga8a35d7159008d49a5e9ded4b41652f96", null ],
    [ "iotbus_i2c_set_address", "group___i2_c.html#gaa96c1f741b95a5c600ec5bb8e0fd474a", null ],
    [ "iotbus_i2c_set_frequency", "group___i2_c.html#ga954f79785b9c74f2b0596977da42955e", null ],
    [ "iotbus_i2c_stop", "group___i2_c.html#gae34a5d482e14f31ef6aabe5be96fed43", null ],
    [ "iotbus_i2c_write", "group___i2_c.html#ga26ad126e64fc712ac19792b05cc8df53", null ]
];