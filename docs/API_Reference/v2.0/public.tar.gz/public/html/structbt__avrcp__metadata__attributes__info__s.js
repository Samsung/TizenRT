var structbt__avrcp__metadata__attributes__info__s =
[
    [ "album", "structbt__avrcp__metadata__attributes__info__s.html#abd2bfb2f79c96ed742334da3edb48a79", null ],
    [ "artist", "structbt__avrcp__metadata__attributes__info__s.html#a4de8da8af30c11f038a75a24cd5f7fae", null ],
    [ "duration", "structbt__avrcp__metadata__attributes__info__s.html#a095ceb846c8c874cd3fcc5cdaf6ade81", null ],
    [ "genre", "structbt__avrcp__metadata__attributes__info__s.html#a4cdb1819c62c0ccd5101171b6bf0f51a", null ],
    [ "number", "structbt__avrcp__metadata__attributes__info__s.html#ae8d56af1549c1276c20aae645c223ab1", null ],
    [ "title", "structbt__avrcp__metadata__attributes__info__s.html#a8214780964530800368b406c681fd1d9", null ],
    [ "total_tracks", "structbt__avrcp__metadata__attributes__info__s.html#a960edf07cfe00593e92735271d8b0c5e", null ]
];