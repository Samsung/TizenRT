var structbt__tds__transport__block__list__s =
[
    [ "data", "structbt__tds__transport__block__list__s.html#a41e007fff212dd9e8e7f4f0273dc398a", null ],
    [ "num_transport_block", "structbt__tds__transport__block__list__s.html#a53a2cc4a850e1e2d3fd8e825d6371a70", null ]
];