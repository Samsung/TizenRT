var dir_7a4cd0262e94fa922c368c1956f19e96 =
[
    [ "tinyalsa.h", "tinyalsa_8h.html", "tinyalsa_8h" ]
];