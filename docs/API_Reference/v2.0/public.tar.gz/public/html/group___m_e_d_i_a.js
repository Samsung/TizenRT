var group___m_e_d_i_a =
[
    [ "BufferObserverInterface.h", "_buffer_observer_interface_8h.html", null ],
    [ "BufferOutputDataSource.h", "_buffer_output_data_source_8h.html", null ],
    [ "DataSource.h", "_data_source_8h.html", null ],
    [ "FileOutputDataSource.h", "_file_output_data_source_8h.html", null ],
    [ "FocusChangeListener.h", "_focus_change_listener_8h.html", null ],
    [ "FocusManager.h", "_focus_manager_8h.html", null ],
    [ "FocusRequest.h", "_focus_request_8h.html", null ],
    [ "MediaPlayer.h", "_media_player_8h.html", null ],
    [ "MediaPlayerObserverInterface.h", "_media_player_observer_interface_8h.html", null ],
    [ "MediaRecorder.h", "_media_recorder_8h.html", null ],
    [ "MediaRecorderObserverInterface.h", "_media_recorder_observer_interface_8h.html", null ],
    [ "MediaTypes.h", "_media_types_8h.html", null ],
    [ "OutputDataSource.h", "_output_data_source_8h.html", null ],
    [ "SocketOutputDataSource.h", "_socket_output_data_source_8h.html", null ],
    [ "SpeechDetectorInterface.h", "_speech_detector_interface_8h.html", null ]
];