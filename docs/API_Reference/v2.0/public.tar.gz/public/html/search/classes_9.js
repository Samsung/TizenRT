var searchData=
[
  ['server_5finfo_5fs',['server_info_s',['../structserver__info__s.html',1,'']]],
  ['socketoutputdatasource',['SocketOutputDataSource',['../classmedia_1_1stream_1_1_socket_output_data_source.html',1,'media::stream']]],
  ['speechdetectorinterface',['SpeechDetectorInterface',['../classmedia_1_1voice_1_1_speech_detector_interface.html',1,'media::voice']]]
];
