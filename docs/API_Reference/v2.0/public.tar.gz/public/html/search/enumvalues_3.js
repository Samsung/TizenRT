var searchData=
[
  ['recorder_5ferror_5fnone',['RECORDER_ERROR_NONE',['../_media_recorder_8h.html#a70ea232d0732785967a185ae4dfc9fe3a5d99e5d77e6c516d054da1959e8919ed',1,'media']]],
  ['recorder_5ferror_5fnot_5falive',['RECORDER_ERROR_NOT_ALIVE',['../_media_recorder_8h.html#a70ea232d0732785967a185ae4dfc9fe3a152214acaf4b4decdcb37e03dbefee03',1,'media']]]
];
