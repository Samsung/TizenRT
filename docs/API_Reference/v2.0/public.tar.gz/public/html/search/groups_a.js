var searchData=
[
  ['task_5fmanager',['Task_Manager',['../group___task___manager.html',1,'']]],
  ['tinyalsa',['TinyAlsa',['../group___tiny_alsa.html',1,'']]]
];
