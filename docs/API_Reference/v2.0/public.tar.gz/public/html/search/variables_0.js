var searchData=
[
  ['ap_5fauth_5ftype',['ap_auth_type',['../structwifi__manager__scan__info__s.html#a8264dd8fa95ff226a79c69d534f5cb9b',1,'wifi_manager_scan_info_s::ap_auth_type()'],['../structwifi__manager__ap__config__s.html#a8264dd8fa95ff226a79c69d534f5cb9b',1,'wifi_manager_ap_config_s::ap_auth_type()']]],
  ['ap_5fcrypto_5ftype',['ap_crypto_type',['../structwifi__manager__scan__info__s.html#ae523c7d21f7c77ada0dafb27d60a6b94',1,'wifi_manager_scan_info_s::ap_crypto_type()'],['../structwifi__manager__ap__config__s.html#ae523c7d21f7c77ada0dafb27d60a6b94',1,'wifi_manager_ap_config_s::ap_crypto_type()']]]
];
