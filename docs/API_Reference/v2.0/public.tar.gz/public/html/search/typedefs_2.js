var searchData=
[
  ['el_5fevent_5ft',['el_event_t',['../group___eventloop.html#gad1674abbd1ba5933f2b984ed3b2dc6b9',1,'eventloop.h']]],
  ['el_5floop_5ft',['el_loop_t',['../group___eventloop.html#ga6526d9b63e5403d6fd17e2e28c43a3c7',1,'eventloop.h']]],
  ['el_5ftimer_5ft',['el_timer_t',['../group___eventloop.html#gabfe44a5630a216aa0f6ed9017aee0d61',1,'eventloop.h']]],
  ['event_5fcallback',['event_callback',['../group___eventloop.html#ga738e168fba764c5985b4a784cc5659c1',1,'eventloop.h']]]
];
