var searchData=
[
  ['thread_5fsafe_5fcallback',['thread_safe_callback',['../group___eventloop.html#ga86dcaedcb4ab0744e58b9b942db122a7',1,'eventloop.h']]],
  ['timeout_5fcallback',['timeout_callback',['../group___eventloop.html#ga9ef3f842f566e9abf752f011accca5f3',1,'eventloop.h']]]
];
