var searchData=
[
  ['el_5fevent_5ftype_5fe',['el_event_type_e',['../group___eventloop.html#ga25bf5a7e63a0ede941060adf195b4c95',1,'eventloop.h']]],
  ['el_5fresult_5ferror_5fe',['el_result_error_e',['../group___eventloop.html#gae5734ae5398e2fea18f91a6cce29b1b0',1,'eventloop.h']]]
];
