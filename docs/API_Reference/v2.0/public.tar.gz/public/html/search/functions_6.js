var searchData=
[
  ['getaudiotype',['getAudioType',['../classmedia_1_1_data_source.html#a47c43a12008b68f4c1c648b9bff0796c',1,'media::DataSource']]],
  ['getchannels',['getChannels',['../classmedia_1_1_data_source.html#ac1e4798484f1e7346ea954794c8f20d3',1,'media::DataSource']]],
  ['getfocusmanager',['getFocusManager',['../classmedia_1_1_focus_manager.html#ab667c9b9da6e73e37216de5f88bd4f6d',1,'media::FocusManager']]],
  ['getid',['getId',['../classmedia_1_1_focus_request.html#a0cb7e1cbd1727bd4f68e15183b22bed9',1,'media::FocusRequest']]],
  ['getlistener',['getListener',['../classmedia_1_1_focus_request.html#a18e2819216007225ed981c95e27acba4',1,'media::FocusRequest']]],
  ['getpcmformat',['getPcmFormat',['../classmedia_1_1_data_source.html#a411f7c785ad6dc4f261c63ab1a99c9bf',1,'media::DataSource']]],
  ['getsamplerate',['getSampleRate',['../classmedia_1_1_data_source.html#a86052196e580f89d2a3291934e243b48',1,'media::DataSource']]],
  ['getvolume',['getVolume',['../classmedia_1_1_media_player.html#a1d6b7354ab8006a5ba930f17928815e7',1,'media::MediaPlayer::getVolume()'],['../classmedia_1_1_media_recorder.html#a790d2c1feb22d5f986b0926ac870e805',1,'media::MediaRecorder::getVolume()']]]
];
