var group___a_d_c =
[
    [ "iotbus_adc.h", "iotbus__adc_8h.html", null ],
    [ "iotbus_adc_context_h", "group___a_d_c.html#ga74f511983e28d0ce1c5531428ac9621e", null ],
    [ "iotbus_adc_state_e", "group___a_d_c.html#gae79ae2188ea4ca0cceabdeae1e2a5f18", [
      [ "IOTBUS_ADC_BUSY", "group___a_d_c.html#ggae79ae2188ea4ca0cceabdeae1e2a5f18a6b0eabbdeeab3f6b5e7b55a476793ac6", null ],
      [ "IOTBUS_ADC_STOP", "group___a_d_c.html#ggae79ae2188ea4ca0cceabdeae1e2a5f18a5828191fc8d3d01c1e1b34a1e3d2d613", null ]
    ] ],
    [ "iotbus_adc_deinit", "group___a_d_c.html#gae43896d9bb5bd896d66287cb413d5806", null ],
    [ "iotbus_adc_get_channel", "group___a_d_c.html#ga2adedcfef81749b535d58c7a06ad8753", null ],
    [ "iotbus_adc_get_sample", "group___a_d_c.html#ga98392b914171b6c2309908e9f63971aa", null ],
    [ "iotbus_adc_get_state", "group___a_d_c.html#ga58b4c05bc709aa52923ce1428aa74f2d", null ],
    [ "iotbus_adc_init", "group___a_d_c.html#gaa262d24e973ae91dd59d738fcc92a280", null ],
    [ "iotbus_adc_set_channel", "group___a_d_c.html#ga753bf4a4e813cacc2767b5c61270f220", null ],
    [ "iotbus_adc_start", "group___a_d_c.html#gac6e43d2dfa0f98abb781a488e6a7ffd9", null ],
    [ "iotbus_adc_stop", "group___a_d_c.html#gaf3e1d0cc20b2f6d657691ba71aa83e74", null ]
];