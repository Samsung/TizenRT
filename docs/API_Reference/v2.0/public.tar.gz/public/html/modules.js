var modules =
[
    [ "ARASTORAGE", "group___a_r_a_s_t_o_r_a_g_e.html", "group___a_r_a_s_t_o_r_a_g_e" ],
    [ "IOTBUS", "group___i_o_t_b_u_s.html", "group___i_o_t_b_u_s" ],
    [ "DM", "group___d_m.html", "group___d_m" ],
    [ "Eventloop", "group___eventloop.html", "group___eventloop" ],
    [ "MEDIA", "group___m_e_d_i_a.html", "group___m_e_d_i_a" ],
    [ "MQTT Client", "group___m_q_t_t.html", "group___m_q_t_t" ],
    [ "SmartThings", "group___smart_things.html", "group___smart_things" ],
    [ "Task_Manager", "group___task___manager.html", "group___task___manager" ],
    [ "TinyAlsa", "group___tiny_alsa.html", "group___tiny_alsa" ],
    [ "Wi-Fi_Manager", "group___wi-_fi___manager.html", "group___wi-_fi___manager" ]
];