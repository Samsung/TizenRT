var structpcm__config =
[
    [ "channels", "structpcm__config.html#a9ed2af39747c91928713f96d4e28b53f", null ],
    [ "format", "structpcm__config.html#a3fa45ac469c7d729ccc263914de71e96", null ],
    [ "period_count", "structpcm__config.html#a69331f21b4dfe981c9e6d1a027b8c755", null ],
    [ "period_size", "structpcm__config.html#a051e413600f0ac702820c15386dd9062", null ],
    [ "rate", "structpcm__config.html#adf42a979321286885fe5a447d48d14d6", null ]
];