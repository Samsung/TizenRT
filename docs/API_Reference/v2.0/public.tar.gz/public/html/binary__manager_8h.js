var binary__manager_8h =
[
    [ "binary_manager_notify_binary_started", "group___binary___manager.html#ga595d4ff8eeb3846a020346b7b367c436", null ],
    [ "binary_manager_register_state_changed_callback", "group___binary___manager.html#ga0544b230e3289546f4dd2e96069abcf3", null ],
    [ "binary_manager_unregister_state_changed_callback", "group___binary___manager.html#ga3882d84b623e5ac77a39d840157f43bf", null ]
];