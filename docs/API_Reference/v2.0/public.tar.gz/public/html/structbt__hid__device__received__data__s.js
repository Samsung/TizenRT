var structbt__hid__device__received__data__s =
[
    [ "address", "structbt__hid__device__received__data__s.html#a45481c7c7ae13f13dbed455332f45cda", null ],
    [ "data", "structbt__hid__device__received__data__s.html#a8f64897c7ccc5c13f276d1d07c4e7095", null ],
    [ "data_size", "structbt__hid__device__received__data__s.html#af69e180c878a9c8f4e45ec7dc25a062f", null ],
    [ "header_type", "structbt__hid__device__received__data__s.html#aefccc8cb6fccc1dae1e373ffbd18327b", null ],
    [ "param_type", "structbt__hid__device__received__data__s.html#acca6617d41f0d2c7343210f39253abbc", null ]
];