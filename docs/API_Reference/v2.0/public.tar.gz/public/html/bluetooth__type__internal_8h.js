var bluetooth__type__internal_8h =
[
    [ "bt_map_client_list_folders_filter_s", "structbt__map__client__list__folders__filter__s.html", null ],
    [ "bt_map_client_list_messages_filter_s", "structbt__map__client__list__messages__filter__s.html", null ],
    [ "bt_map_client_message_item_s", "structbt__map__client__message__item__s.html", null ],
    [ "bt_map_client_push_message_args_s", "structbt__map__client__push__message__args__s.html", null ],
    [ "bt_map_client_message_s", "structbt__map__client__message__s.html", null ],
    [ "bt_hf_call_status_info_s", "structbt__hf__call__status__info__s.html", "structbt__hf__call__status__info__s" ],
    [ "bt_le_conn_update_s", "structbt__le__conn__update__s.html", "structbt__le__conn__update__s" ],
    [ "bt_dpm_device_list_s", "structbt__dpm__device__list__s.html", null ],
    [ "bt_dpm_uuids_list_s", "structbt__dpm__uuids__list__s.html", null ],
    [ "bt_manufacturer_data", "structbt__manufacturer__data.html", null ],
    [ "bt_device_att_mtu_info_s", "structbt__device__att__mtu__info__s.html", "structbt__device__att__mtu__info__s" ],
    [ "tds_transport_data_s", "structtds__transport__data__s.html", null ],
    [ "bt_tds_transport_block_list_s", "structbt__tds__transport__block__list__s.html", "structbt__tds__transport__block__list__s" ],
    [ "bt_hf_vendor_dep_at_cmd_s", "structbt__hf__vendor__dep__at__cmd__s.html", "structbt__hf__vendor__dep__at__cmd__s" ],
    [ "otp_object_metadata_s", "structotp__object__metadata__s.html", null ],
    [ "bt_otp_object_list_s", "structbt__otp__object__list__s.html", "structbt__otp__object__list__s" ],
    [ "BT_SC_MAP_SERVICE_MASK", "bluetooth__type__internal_8h.html#aa8a981019e453b830af6e70ac49c2299", null ],
    [ "bt_adapter_connectable_changed_cb", "bluetooth__type__internal_8h.html#adb8af81b031b51b0ab1624fd7c5b9c8b", null ],
    [ "bt_adapter_le_state_changed_cb", "bluetooth__type__internal_8h.html#a7a68656079559156eecb5719a287435f", null ],
    [ "bt_adapter_manufacturer_data_changed_cb", "bluetooth__type__internal_8h.html#a24d685a049c968a7a2aa9e568e0792e5", null ],
    [ "bt_ag_vendor_cmd_cb", "bluetooth__type__internal_8h.html#a20d47faedacb5cf9bd91ea10dbee9891", null ],
    [ "bt_avrcp_delay_changed_cb", "bluetooth__type__internal_8h.html#ae3c715b83d710ce3eb939e4fe24cf520", null ],
    [ "bt_device_att_mtu_changed_cb", "bluetooth__type__internal_8h.html#a7094794f7fa395902650902f29f9dc67", null ],
    [ "bt_device_trusted_profiles_cb", "bluetooth__type__internal_8h.html#a77e8936a1b5044dd6ccbd493be373158", null ],
    [ "bt_hf_call_handling_event_cb", "bluetooth__type__internal_8h.html#ae9737cc803943a54fe2d91eb611e8c8c", null ],
    [ "bt_hf_multi_call_handling_event_cb", "bluetooth__type__internal_8h.html#ad28ec64eb4117b72e83cd5d13d650ec0", null ],
    [ "bt_hf_remote_call_event_cb", "bluetooth__type__internal_8h.html#ae68fbe3b42aa78c8bf88404c6e4c2101", null ],
    [ "bt_hf_sco_state_changed_cb", "bluetooth__type__internal_8h.html#a9366e498bead93d141009e9d3fe0a0c8", null ],
    [ "bt_hf_speaker_gain_changed_cb", "bluetooth__type__internal_8h.html#a3457ca08180934ccd74a37f2f8265845", null ],
    [ "bt_hrp_collector_bsl_read_completed_cb", "bluetooth__type__internal_8h.html#a589192037b132ab98cf1c334ae979d69", null ],
    [ "bt_hrp_collector_heart_rate_value_changed_cb", "bluetooth__type__internal_8h.html#a9041288f437e404be0e68ef984958331", null ],
    [ "bt_hrp_collector_scan_result_cb", "bluetooth__type__internal_8h.html#a947180d76b037d3f5e18fed33507f7fb", null ],
    [ "bt_map_client_session_info_h", "bluetooth__type__internal_8h.html#aa9cc2e927e446e351b08bba1384aad24", null ],
    [ "bt_opp_server_push_requested_cb", "bluetooth__type__internal_8h.html#a2b7e45e946717b9b1b6d3c38aa7f0357", null ],
    [ "bt_otp_client_h", "bluetooth__type__internal_8h.html#aeca54a00e6fb958f7e0bae66dddc5677", null ],
    [ "bt_proximity_monitor_connection_state_changed_cb", "bluetooth__type__internal_8h.html#a9c51eec647b2c2dcb4fb73d52b821f1f", null ],
    [ "bt_proximity_monitor_h", "bluetooth__type__internal_8h.html#a461beec84d8d9f5c6b5c5cadeddfff99", null ],
    [ "bt_proximity_reporter_connection_state_changed_cb", "bluetooth__type__internal_8h.html#a6fb5be1e7e43c19197db7df28a94937b", null ],
    [ "bt_proximity_reporter_h", "bluetooth__type__internal_8h.html#a0e82282d10c00db1afb84efd60f08545", null ],
    [ "bt_proximity_reporter_property_changed_cb", "bluetooth__type__internal_8h.html#a3e139f0458d9023ae0a5da9468ca407e", null ],
    [ "bt_tds_seeker_h", "bluetooth__type__internal_8h.html#adae26c269d14211692d82cf0a8489ebd", null ],
    [ "bt_adapter_le_scan_type_e", "bluetooth__type__internal_8h.html#a31f34f95dd499356d44707df5be3a4e6", null ],
    [ "bt_adapter_le_state_e", "bluetooth__type__internal_8h.html#aec44abbf44a019c2fd95097ea639fc50", [
      [ "BT_ADAPTER_LE_DISABLED", "bluetooth__type__internal_8h.html#aec44abbf44a019c2fd95097ea639fc50ab2cc3c878166a0de4ed3d18a9579975a", null ],
      [ "BT_ADAPTER_LE_ENABLED", "bluetooth__type__internal_8h.html#aec44abbf44a019c2fd95097ea639fc50afea818b8a705c693be91ea73da29cf7f", null ]
    ] ],
    [ "bt_ag_call_event_e", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1f", [
      [ "BT_AG_CALL_EVENT_IDLE", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa06be850ee22005422c4b34102edc9b28", null ],
      [ "BT_AG_CALL_EVENT_ANSWERED", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa65877207c8cbf5154103e1351d617cfc", null ],
      [ "BT_AG_CALL_EVENT_HELD", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa37f6dbf45b35562fe97b41fcb75508fa", null ],
      [ "BT_AG_CALL_EVENT_RETRIEVED", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa3de8bfefeb33907f469ccc0ff24faf15", null ],
      [ "BT_AG_CALL_EVENT_DIALING", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa974a2c5986486ee96d37bb76b7e3727c", null ],
      [ "BT_AG_CALL_EVENT_ALERTING", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1fa7cc122c65b0b1f7e23a554fc19d186e1", null ],
      [ "BT_AG_CALL_EVENT_INCOMING", "bluetooth__type__internal_8h.html#a9b275c9b5ee8875836ed0bee51e5bb1faf00d77069e53b6d6912ebcb1f1e9f383", null ]
    ] ],
    [ "bt_ag_call_state_e", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896", [
      [ "BT_AG_CALL_STATE_IDLE", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896a54e5d342c3838f10b23ae74f9e48528a", null ],
      [ "BT_AG_CALL_STATE_ACTIVE", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896aac05c0578c66dd0606a43c0f0fc9b936", null ],
      [ "BT_AG_CALL_STATE_HELD", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896a00b9f106eb74604e8e6010f64473bba8", null ],
      [ "BT_AG_CALL_STATE_DIALING", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896a89058b4e6b2bebcdb7a6efca03fae907", null ],
      [ "BT_AG_CALL_STATE_ALERTING", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896aa16d12d46b41b11f2707dbe8601e26df", null ],
      [ "BT_AG_CALL_STATE_INCOMING", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896affe50b7aa7409a257fe6572e8cf45108", null ],
      [ "BT_AG_CALL_STATE_WAITING", "bluetooth__type__internal_8h.html#ae4444e553a8dabb72aef7537ac197896a4bb4a33424d91f3204bd71ec28665b61", null ]
    ] ],
    [ "bt_att_error_e", "bluetooth__type__internal_8h.html#a50d6cd91e6fa808cc0a4724b8bdd7ac8", null ],
    [ "bt_audio_role_e", "bluetooth__type__internal_8h.html#a3bce86f499c89577d11c914525b364bc", null ],
    [ "bt_authentication_type_info_e", "bluetooth__type__internal_8h.html#a83a3e6bcd178562cbb5e3c01c09ea4c7", [
      [ "BT_AUTH_KEYBOARD_PASSKEY_DISPLAY", "bluetooth__type__internal_8h.html#a83a3e6bcd178562cbb5e3c01c09ea4c7a3a8e4c898b7fc93a714e7d83d8886551", null ],
      [ "BT_AUTH_PIN_REQUEST", "bluetooth__type__internal_8h.html#a83a3e6bcd178562cbb5e3c01c09ea4c7a2bb7e7d2697fe6c9d37004e6dabd9a89", null ],
      [ "BT_AUTH_PASSKEY_CONFIRM_REQUEST", "bluetooth__type__internal_8h.html#a83a3e6bcd178562cbb5e3c01c09ea4c7a55a802e5da37aed85757ace4df3af5d5", null ]
    ] ],
    [ "bt_dpm_allow_e", "bluetooth__type__internal_8h.html#af6015771c862b25d9153c2ee8c50c65a", [
      [ "BT_DPM_ERROR", "bluetooth__type__internal_8h.html#af6015771c862b25d9153c2ee8c50c65aa750b7c7b3a13142a73c5faebe71ee826", null ],
      [ "BT_DPM_BT_ALLOWED", "bluetooth__type__internal_8h.html#af6015771c862b25d9153c2ee8c50c65aa17b346037b5d83e5d60f736da9e71d19", null ],
      [ "BT_DPM_HANDSFREE_ONLY", "bluetooth__type__internal_8h.html#af6015771c862b25d9153c2ee8c50c65aa0847e92d337f4a97d181fa7b24dc9a2a", null ],
      [ "BT_DPM_BT_RESTRICTED", "bluetooth__type__internal_8h.html#af6015771c862b25d9153c2ee8c50c65aa9132ef1cb2e210efaceba5fb8721569e", null ]
    ] ],
    [ "bt_dpm_profile_e", "bluetooth__type__internal_8h.html#a380ca0a4efcd1f60125bffa62f062294", null ],
    [ "bt_dpm_status_e", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6", [
      [ "BT_DPM_ALLOWED", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6ae7ccd68dc2d7aa1c95005e4673765798", null ],
      [ "BT_DPM_RESTRICTED", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6ababdde46732f0d127e93378bcb4706f7", null ],
      [ "BT_DPM_ENABLE", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6a983085e07020929c4405b77d11f3e851", null ],
      [ "BT_DPM_DISABLE", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6a21c29f6272ff9f7aaa3f7900459083fe", null ],
      [ "BT_DPM_FALSE", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6a12d16c838f7fbc0a767a83a4ffddceec", null ],
      [ "BT_DPM_TRUE", "bluetooth__type__internal_8h.html#a08147ef67f7491fcf8a125176a98f0c6ae25755015c303e07c342b93a7a03b54f", null ]
    ] ],
    [ "bt_hf_call_event_e", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0", [
      [ "BT_HF_CALL_EVENT_IDLE", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0ae9ab7dbcf34d0390e62658943273f952", null ],
      [ "BT_HF_CALL_EVENT_ANSWER", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a37e6e897ac222daa69711b2ecc75f89c", null ],
      [ "BT_HF_CALL_EVENT_HOLD", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0ac3fa984c9cd2f197bf15c08fa9bc6ffb", null ],
      [ "BT_HF_CALL_EVENT_RETRIEVE", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a15d5ffac8e8e812b717ed5782e345621", null ],
      [ "BT_HF_CALL_EVENT_DIAL", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0aabec43aa18bcc603346dbf6fda1e729e", null ],
      [ "BT_HF_CALL_EVENT_ALERT", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a03ec31e0e5cb0ad645351ad8516984cf", null ],
      [ "BT_HF_CALL_EVENT_INCOMING", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a66d1bd167256948c5692c7b5c333c68f", null ],
      [ "BT_HF_CALL_EVENT_REDIAL", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0ae31cbfa3946e056d94bc9350eeaba11b", null ],
      [ "BT_HF_CALL_EVENT_RELEASE_ALL_NONACTIVE_CALLS", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a6d25ff3a0c9daf0a73899d9109444f09", null ],
      [ "BT_HF_CALL_EVENT_ACCEPT_AND_RELEASE", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0ada1fc20523ae6e2e1565cb43778fd94f", null ],
      [ "BT_HF_CALL_EVENT_ACCEPT_AND_HOLD", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a0fceab63143c9e493427ae02d1b69932", null ],
      [ "BT_HF_CALL_EVENT_ADD_TO_CONVERSATION", "bluetooth__type__internal_8h.html#a4ea3e857bfe05731ad169803d1947cf0a3b3122c893b6744a903a844a830776df", null ]
    ] ],
    [ "bt_hf_call_handling_event_e", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08b", [
      [ "BT_HF_CALL_HANDLING_EVENT_ANSWER", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08bafcb7b47ba975c115ba5226cbf96d85df", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_RELEASE", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08baf0d353625302d8d818eacf9a375e681a", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_REJECT", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08bac6d16a9ce725217185c5d9135d8e5e42", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_RING", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba43c4367ad0bcb5eb296c48e4cb03bff6", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_CALL_STARTED", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba7d0588fe4cc0f6214fad9159c24894c2", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_CALL_ENDED", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08baa64d9f33b9bf9be59fcabc0047a28c62", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_VOICE_RECOGNITION_ENABLED", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba36264355d1ec7f5ad96da3b480960b2c", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_VOICE_RECOGNITION_DISABLED", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba046e71af4176061ae3d1fe1b059e251e", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_VENDOR_DEP_CMD", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08bab1bace1e0db502680328b70df0678557", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_WAITING", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba7ee0b370ca497b618cd26e9e5fb4657e", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_HELD", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08baf82af503e1a62051a9aba497d8bdfaab", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_UNHELD", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08ba89bbf3ccff854e2f7cb331267ce7a705", null ],
      [ "BT_HF_CALL_HANDLING_EVENT_SWAPPED", "bluetooth__type__internal_8h.html#a06c56a79107bf5b58dd597e3d08cc08baa272ec5074defc08eba1203d79785e60", null ]
    ] ],
    [ "bt_hf_multi_call_handling_event_e", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492", [
      [ "BT_HF_MULTI_CALL_HANDLING_EVENT_RELEASE_HELD_CALLS", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492ad0ba364ed871a966ecaec1523230b044", null ],
      [ "BT_HF_MULTI_CALL_HANDLING_EVENT_RELEASE_ACTIVE_CALLS", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492aa4578ab6972f9448543fa0d59525396b", null ],
      [ "BT_HF_MULTI_CALL_HANDLING_EVENT_ACTIVATE_HELD_CALL", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492a8f28020dfdd6ea552ea2b17bbd65b87f", null ],
      [ "BT_HF_MULTI_CALL_HANDLING_EVENT_MERGE_CALLS", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492a2f81c3d0ce86330b59d93bb43ac5dea2", null ],
      [ "BT_HF_MULTI_CALL_HANDLING_EVENT_EXPLICIT_CALL_TRANSFER", "bluetooth__type__internal_8h.html#a76f9428027ec85650901cea0f9d7c492ad4c45975ed76556bd8ca1df9308af074", null ]
    ] ],
    [ "bt_hf_remote_call_event_e", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54", [
      [ "BT_HF_REMOTE_CALL_EVENT_IDLE", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a1d91ca5dad157a0fda8b2bcacf52c234", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_INCOMING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a9327e37d472197cc277612610e34e125", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_DIALING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a464a4e6261a4a2f9e160fe8d0023fb4b", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_ALERTING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54aba7c7b53be0c65bd93d4a21ba45f5557", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_CALL_TERMINATED", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54ada61dbff7f0d037a3be1bf19cf676466", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_CALL_STARTED", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54ac7b20a6ffd87770f0835bb1456f07ee9", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_CALL_ENDED", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a3aa53d00a94a01cca4e3c3ed4e9b1ebc", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_UNHELD", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a1486c58d5a1cca7ffabfb7f783d57b80", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_SWAPPED", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54adb8dc57854d7d5ed466775463f2a82d2", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_HELD", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a88fe08054fc860feff1494cc948af03a", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_RINGING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54af2348ab486daac599885cce4eee80c85", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_WAITING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a0236e615b7e6e6c047a1d0ff288c4381", null ],
      [ "BT_HF_REMOTE_CALL_EVENT_FAILED_TO_DIALING", "bluetooth__type__internal_8h.html#a617a08614508b43f68a431a8a4e3dc54a067b840a94074808463ffdbf1ecdca20", null ]
    ] ],
    [ "bt_hrp_sensor_advertising_state_e", "bluetooth__type__internal_8h.html#a1b07c19b202305bc1506374087bb47ac", [
      [ "BT_HRP_SENSOR_ADVERTISING_STOPPED", "bluetooth__type__internal_8h.html#a1b07c19b202305bc1506374087bb47aca168d49431312268c4f4a6690e03ef0bf", null ],
      [ "BT_HRP_SENSOR_ADVERTISING_STARTED", "bluetooth__type__internal_8h.html#a1b07c19b202305bc1506374087bb47acac27a01acd1899d0f50e1a1c513a7ff97", null ]
    ] ],
    [ "bt_opp_transfer_type_t", "bluetooth__type__internal_8h.html#afa546ab00f08d17770010ec83b2b01ce", [
      [ "BT_TRANSFER_INBOUND", "bluetooth__type__internal_8h.html#afa546ab00f08d17770010ec83b2b01cead673c15427227c905e1a919ce83b82e4", null ],
      [ "BT_TRANSFER_OUTBOUND", "bluetooth__type__internal_8h.html#afa546ab00f08d17770010ec83b2b01cea27d98eda8692297033f273e84692be8e", null ]
    ] ],
    [ "bt_otp_error_e", "bluetooth__type__internal_8h.html#ace08d9542af6d7a03cc7d46fdf396e88", null ],
    [ "bt_proximity_property_t", "bluetooth__type__internal_8h.html#af67592952b51702fe1eabf5321852cad", [
      [ "BT_PROXIMITY_LINKLOSS_ALERT", "bluetooth__type__internal_8h.html#af67592952b51702fe1eabf5321852cada876d4472f9b0903cfe202688aff4c4f9", null ],
      [ "BT_PROXIMITY_IMMEDIATE_ALERT", "bluetooth__type__internal_8h.html#af67592952b51702fe1eabf5321852cadadc28d56c9da76c915c21288a9f25baf5", null ],
      [ "BT_PROXIMITY_TX_POWER", "bluetooth__type__internal_8h.html#af67592952b51702fe1eabf5321852cada5674d7d04f3ff35081322c68d6d73c6b", null ]
    ] ],
    [ "bt_proximity_role_t", "bluetooth__type__internal_8h.html#a3b6d56c87b4f1bd761085c4b0ab690db", [
      [ "BT_PROXIMITY_REPORTER", "bluetooth__type__internal_8h.html#a3b6d56c87b4f1bd761085c4b0ab690dba7e382ca4fd83cfacba80723ad59c3b97", null ],
      [ "BT_PROXIMITY_MONITOR", "bluetooth__type__internal_8h.html#a3b6d56c87b4f1bd761085c4b0ab690dbae41e4b84b9a4dffd060631fa736e7110", null ]
    ] ],
    [ "bt_restricted_profile_t", "bluetooth__type__internal_8h.html#a79273e2bd43d5585c06766ec3515d703", null ],
    [ "bt_serv_char_type_t", "bluetooth__type__internal_8h.html#a28374e43d76d74be15bb77782b22e534", null ],
    [ "bt_tds_transport_state_e", "bluetooth__type__internal_8h.html#acbbe90070741eaef2006da0a88f43473", [
      [ "BT_TDS_TRANSPORT_STATE_OFF", "bluetooth__type__internal_8h.html#acbbe90070741eaef2006da0a88f43473a6b7a4301ffc1b8f401c04d2c8d2d3ecd", null ],
      [ "BT_TDS_TRANSPORT_STATE_ON", "bluetooth__type__internal_8h.html#acbbe90070741eaef2006da0a88f43473a1277b462bbd123a20fba9e7d242ddfe7", null ],
      [ "BT_TDS_TRANSPORT_STATE_UNAVAILABLE", "bluetooth__type__internal_8h.html#acbbe90070741eaef2006da0a88f43473a7a5ee3d502d396bd57634a6e62f74320", null ]
    ] ],
    [ "bt_trusted_profile_t", "bluetooth__type__internal_8h.html#adddfac7c32bf1f5487167d60497c20a5", null ]
];