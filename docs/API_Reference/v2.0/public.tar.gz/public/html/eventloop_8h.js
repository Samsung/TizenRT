var eventloop_8h =
[
    [ "EVENTLOOP_CALLBACK_STOP", "group___eventloop.html#ga27523606fd18ebc9b5a77f30e12549e4", null ],
    [ "el_event_t", "group___eventloop.html#gad1674abbd1ba5933f2b984ed3b2dc6b9", null ],
    [ "el_loop_t", "group___eventloop.html#ga6526d9b63e5403d6fd17e2e28c43a3c7", null ],
    [ "el_timer_t", "group___eventloop.html#gabfe44a5630a216aa0f6ed9017aee0d61", null ],
    [ "event_callback", "group___eventloop.html#ga738e168fba764c5985b4a784cc5659c1", null ],
    [ "thread_safe_callback", "group___eventloop.html#ga86dcaedcb4ab0744e58b9b942db122a7", null ],
    [ "timeout_callback", "group___eventloop.html#ga9ef3f842f566e9abf752f011accca5f3", null ],
    [ "el_event_type_e", "group___eventloop.html#ga25bf5a7e63a0ede941060adf195b4c95", null ],
    [ "el_result_error_e", "group___eventloop.html#gae5734ae5398e2fea18f91a6cce29b1b0", null ],
    [ "eventloop_add_event_handler", "group___eventloop.html#ga6ce7f6bbd66b425c2cf6e817dabdb37e", null ],
    [ "eventloop_add_timer", "group___eventloop.html#ga3b2f79a70bbf65fcd1d15de36c0b29c2", null ],
    [ "eventloop_add_timer_async", "group___eventloop.html#gae82add02d8ea8096c5dad60fafac4867", null ],
    [ "eventloop_del_event_handler", "group___eventloop.html#ga09b501d5f501530f3f5c3e90fa148b05", null ],
    [ "eventloop_delete_timer", "group___eventloop.html#ga761753b2105a3ba2edc08ef8750ef597", null ],
    [ "eventloop_loop_run", "group___eventloop.html#ga887e6bb452184b0749329aefc8d00746", null ],
    [ "eventloop_loop_stop", "group___eventloop.html#ga5393222f7aa03d540f3d96b99d34f23b", null ],
    [ "eventloop_send_event", "group___eventloop.html#ga57ef3930b8de5332d75f152a31220333", null ],
    [ "eventloop_thread_safe_function_call", "group___eventloop.html#ga56c08413dea3772b569645a7a6aae98b", null ]
];