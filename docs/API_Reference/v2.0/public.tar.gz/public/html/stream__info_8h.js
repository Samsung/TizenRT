var stream__info_8h =
[
    [ "stream_info_s", "structstream__info__s.html", null ],
    [ "stream_focus_state_e", "stream__info_8h.html#a6f9bba3ec572f484e1fcd8d51301b03c", [
      [ "STREAM_FOCUS_STATE_RELEASED", "stream__info_8h.html#a6f9bba3ec572f484e1fcd8d51301b03ca0d762ae7cd2be3f5f0ee4af9baa2ef0b", null ],
      [ "STREAM_FOCUS_STATE_ACQUIRED", "stream__info_8h.html#a6f9bba3ec572f484e1fcd8d51301b03cad8447a0b4d0ae978798074abbc10cf16", null ]
    ] ],
    [ "stream_policy_e", "stream__info_8h.html#a1c35499eff90f5a24a591820dd6d8d1f", null ]
];