var structbt__gatt__client__att__mtu__info__s =
[
    [ "mtu", "structbt__gatt__client__att__mtu__info__s.html#a5ac894ab93685970e62fbf6756f38309", null ],
    [ "remote_address", "structbt__gatt__client__att__mtu__info__s.html#a7cb374ca04ac60371bf1428c9f154890", null ],
    [ "status", "structbt__gatt__client__att__mtu__info__s.html#aeed08ea57af6f7be240e2bf66162389f", null ]
];