var structbt__pbap__vcard__info__s =
[
    [ "contact_name", "structbt__pbap__vcard__info__s.html#a9cb43ace0783e4d1ca9313a4d6a2f845", null ],
    [ "index", "structbt__pbap__vcard__info__s.html#a750b5d744c39a06bfb13e6eb010e35d0", null ]
];