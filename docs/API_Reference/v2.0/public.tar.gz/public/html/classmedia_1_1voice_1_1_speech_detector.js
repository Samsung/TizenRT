var classmedia_1_1voice_1_1_speech_detector =
[
    [ "deinitEndPointDetect", "classmedia_1_1voice_1_1_speech_detector.html#a3e62af12e32872d493d1ec48b9eeb4ff", null ],
    [ "deinitKeywordDetect", "classmedia_1_1voice_1_1_speech_detector.html#ae347b7b49f012ab9f3d4cf05467df46c", null ],
    [ "detectEndPoint", "classmedia_1_1voice_1_1_speech_detector.html#a2d3db6c4a32581e468eb36b419c38f30", null ],
    [ "initEndPointDetect", "classmedia_1_1voice_1_1_speech_detector.html#a24ee27596b652213a9b34a86fbf3c669", null ],
    [ "initKeywordDetect", "classmedia_1_1voice_1_1_speech_detector.html#a66456b5512c18883cf45a9a0b67879ae", null ],
    [ "startEndPointDetect", "classmedia_1_1voice_1_1_speech_detector.html#aad3a056338a702d73faccd67a6b55c60", null ],
    [ "startKeywordDetect", "classmedia_1_1voice_1_1_speech_detector.html#a170f8bfe0adb0276cd7b019cc960a28d", null ],
    [ "waitEndPoint", "classmedia_1_1voice_1_1_speech_detector.html#a26f0bf36fb22176a6df4dc413dce7ddf", null ]
];