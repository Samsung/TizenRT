var classmedia_1_1_focus_request_1_1_builder =
[
    [ "Builder", "classmedia_1_1_focus_request_1_1_builder.html#a4c5b1b5b658880619647b859000724fc", null ],
    [ "build", "classmedia_1_1_focus_request_1_1_builder.html#a9fda1360108adbe5e01e9514d0041fd8", null ],
    [ "setFocusChangeListener", "classmedia_1_1_focus_request_1_1_builder.html#ae2e6faaf79e53d657df7fd62c3cc8e1f", null ]
];