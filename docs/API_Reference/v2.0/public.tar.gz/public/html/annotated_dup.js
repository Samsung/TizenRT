var annotated_dup =
[
    [ "media", null, [
      [ "stream", null, [
        [ "BufferObserverInterface", "classmedia_1_1stream_1_1_buffer_observer_interface.html", "classmedia_1_1stream_1_1_buffer_observer_interface" ],
        [ "BufferOutputDataSource", "classmedia_1_1stream_1_1_buffer_output_data_source.html", "classmedia_1_1stream_1_1_buffer_output_data_source" ],
        [ "FileInputDataSource", "classmedia_1_1stream_1_1_file_input_data_source.html", "classmedia_1_1stream_1_1_file_input_data_source" ],
        [ "FileOutputDataSource", "classmedia_1_1stream_1_1_file_output_data_source.html", "classmedia_1_1stream_1_1_file_output_data_source" ],
        [ "InputDataSource", "classmedia_1_1stream_1_1_input_data_source.html", "classmedia_1_1stream_1_1_input_data_source" ],
        [ "OutputDataSource", "classmedia_1_1stream_1_1_output_data_source.html", "classmedia_1_1stream_1_1_output_data_source" ],
        [ "SocketOutputDataSource", "classmedia_1_1stream_1_1_socket_output_data_source.html", "classmedia_1_1stream_1_1_socket_output_data_source" ]
      ] ],
      [ "voice", null, [
        [ "SpeechDetectorInterface", "classmedia_1_1voice_1_1_speech_detector_interface.html", null ]
      ] ],
      [ "DataSource", "classmedia_1_1_data_source.html", "classmedia_1_1_data_source" ],
      [ "FocusChangeListener", "classmedia_1_1_focus_change_listener.html", "classmedia_1_1_focus_change_listener" ],
      [ "FocusManager", "classmedia_1_1_focus_manager.html", "classmedia_1_1_focus_manager" ],
      [ "FocusRequest", "classmedia_1_1_focus_request.html", "classmedia_1_1_focus_request" ],
      [ "MediaPlayer", "classmedia_1_1_media_player.html", "classmedia_1_1_media_player" ],
      [ "MediaPlayerObserverInterface", "classmedia_1_1_media_player_observer_interface.html", "classmedia_1_1_media_player_observer_interface" ],
      [ "MediaRecorder", "classmedia_1_1_media_recorder.html", "classmedia_1_1_media_recorder" ],
      [ "MediaRecorderObserverInterface", "classmedia_1_1_media_recorder_observer_interface.html", "classmedia_1_1_media_recorder_observer_interface" ]
    ] ],
    [ "_mqtt_client_config_s", "struct__mqtt__client__config__s.html", "struct__mqtt__client__config__s" ],
    [ "_mqtt_client_s", "struct__mqtt__client__s.html", "struct__mqtt__client__s" ],
    [ "_mqtt_msg_s", "struct__mqtt__msg__s.html", "struct__mqtt__msg__s" ],
    [ "_mqtt_tls_param_s", "struct__mqtt__tls__param__s.html", null ],
    [ "_st_things_get_request_message", "struct__st__things__get__request__message.html", "struct__st__things__get__request__message" ],
    [ "_st_things_representation", "struct__st__things__representation.html", "struct__st__things__representation" ],
    [ "_st_things_set_request_message", "struct__st__things__set__request__message.html", "struct__st__things__set__request__message" ],
    [ "client_info_s", "structclient__info__s.html", null ],
    [ "dm_lwm2m_context_s", "structdm__lwm2m__context__s.html", null ],
    [ "dm_scan_info_s", "structdm__scan__info__s.html", null ],
    [ "iotbus_spi_config_s", "structiotbus__spi__config__s.html", null ],
    [ "pcm_config", "structpcm__config.html", "structpcm__config" ],
    [ "server_info_s", "structserver__info__s.html", null ],
    [ "tm_appinfo_list_s", "structtm__appinfo__list__s.html", null ],
    [ "tm_appinfo_s", "structtm__appinfo__s.html", null ],
    [ "tm_msg_s", "structtm__msg__s.html", null ],
    [ "wifi_manager_ap_config_s", "structwifi__manager__ap__config__s.html", "structwifi__manager__ap__config__s" ],
    [ "wifi_manager_cb_s", "structwifi__manager__cb__s.html", null ],
    [ "wifi_manager_info_s", "structwifi__manager__info__s.html", "structwifi__manager__info__s" ],
    [ "wifi_manager_reconnect_config_s", "structwifi__manager__reconnect__config__s.html", null ],
    [ "wifi_manager_scan_info_s", "structwifi__manager__scan__info__s.html", "structwifi__manager__scan__info__s" ],
    [ "wifi_manager_softap_config_s", "structwifi__manager__softap__config__s.html", null ],
    [ "wifi_manager_stats_s", "structwifi__manager__stats__s.html", null ]
];