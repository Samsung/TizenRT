var structbt__device__connection__info__s =
[
    [ "disconn_reason", "structbt__device__connection__info__s.html#a52930c433c259024ba971b52cbf465af", null ],
    [ "link", "structbt__device__connection__info__s.html#af1f14b1bf73c6ff5221935e28fad1b27", null ],
    [ "remote_address", "structbt__device__connection__info__s.html#a7cb374ca04ac60371bf1428c9f154890", null ]
];