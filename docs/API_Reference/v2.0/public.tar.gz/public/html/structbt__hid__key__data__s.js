var structbt__hid__key__data__s =
[
    [ "key", "structbt__hid__key__data__s.html#a2f51fd55fd59332019cd4a8676760872", null ],
    [ "modifier", "structbt__hid__key__data__s.html#ae3f31c0d691c7a842dbddc35afe1e4e5", null ]
];