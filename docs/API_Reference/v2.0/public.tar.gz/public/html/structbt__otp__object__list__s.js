var structbt__otp__object__list__s =
[
    [ "data", "structbt__otp__object__list__s.html#a79f75d9cf6995f506bd2a9ec244a5513", null ],
    [ "num_objects", "structbt__otp__object__list__s.html#ab000eabbed09cacdd40b5585dd784e55", null ]
];