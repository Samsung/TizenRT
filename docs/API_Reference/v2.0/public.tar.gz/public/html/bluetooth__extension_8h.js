var bluetooth__extension_8h =
[
    [ "bt_ag_close_sco", "bluetooth__extension_8h.html#ad57194941c0b7efe66ce724cda3f76e3", null ],
    [ "bt_ag_open_sco", "bluetooth__extension_8h.html#a8fe12b3cb2ed1818f8b07e1dae3dd145", null ]
];