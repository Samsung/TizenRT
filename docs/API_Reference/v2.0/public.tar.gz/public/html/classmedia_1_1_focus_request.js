var classmedia_1_1_focus_request =
[
    [ "Builder", "classmedia_1_1_focus_request_1_1_builder.html", "classmedia_1_1_focus_request_1_1_builder" ],
    [ "getId", "classmedia_1_1_focus_request.html#a0cb7e1cbd1727bd4f68e15183b22bed9", null ],
    [ "getListener", "classmedia_1_1_focus_request.html#a18e2819216007225ed981c95e27acba4", null ]
];