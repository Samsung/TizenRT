var structbt__class__s =
[
    [ "major_device_class", "structbt__class__s.html#a687630bfb5d7c409c3456b58a2bec278", null ],
    [ "major_service_class_mask", "structbt__class__s.html#a4f3e40231db4296d516b2f02cbf8b9ce", null ],
    [ "minor_device_class", "structbt__class__s.html#a58a69458031fe0ac01121f49ca86211d", null ]
];