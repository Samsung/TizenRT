var classmedia_1_1_focus_manager =
[
    [ "abandonFocus", "classmedia_1_1_focus_manager.html#a5759866729cfacfe13544aacb0e7e6fd", null ],
    [ "requestFocus", "classmedia_1_1_focus_manager.html#ad388b3e1db20f9c7023092d1bae953f2", null ]
];