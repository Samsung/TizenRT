var structbt__adapter__le__service__data__s =
[
    [ "service_data", "structbt__adapter__le__service__data__s.html#acef65cc0e6893bbd4fd0f51f12b7364f", null ],
    [ "service_data_len", "structbt__adapter__le__service__data__s.html#a4ce6eaa6920e765e3ec63d4fc10b1ea2", null ],
    [ "service_uuid", "structbt__adapter__le__service__data__s.html#aa5d6aaed319d04eeef545a940fa41f93", null ]
];