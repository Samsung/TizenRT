var structbt__adapter__device__discovery__info__s =
[
    [ "appearance", "structbt__adapter__device__discovery__info__s.html#aa2dfd686c4a41f331d8931095620f17c", null ],
    [ "bt_class", "structbt__adapter__device__discovery__info__s.html#adf8042e756ad934edfc47b038334a92c", null ],
    [ "is_bonded", "structbt__adapter__device__discovery__info__s.html#a75d12d95b85f9a7a1814534fafdbdd82", null ],
    [ "manufacturer_data", "structbt__adapter__device__discovery__info__s.html#a1fa2f949739a66f8b4c052c7685c82fa", null ],
    [ "manufacturer_data_len", "structbt__adapter__device__discovery__info__s.html#abb0dc19d8a41b0986d130c139dd95614", null ],
    [ "remote_address", "structbt__adapter__device__discovery__info__s.html#a7cb374ca04ac60371bf1428c9f154890", null ],
    [ "remote_name", "structbt__adapter__device__discovery__info__s.html#a4cd9a62ec7e9a8a2dd0ab9edd782b2a4", null ],
    [ "rssi", "structbt__adapter__device__discovery__info__s.html#ab6f4522a5a5c4577c16d0e23339a1414", null ],
    [ "service_count", "structbt__adapter__device__discovery__info__s.html#aa20c27a9adf408745c89d11e6ec54ed5", null ],
    [ "service_uuid", "structbt__adapter__device__discovery__info__s.html#acac7c855441ca3239a09a49918adcaf5", null ]
];