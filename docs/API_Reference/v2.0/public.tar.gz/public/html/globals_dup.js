var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "i", "globals_i.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "w", "globals_w.html", null ]
];