var dir_23309415732c32869e0b217406e16511 =
[
    [ "SpeechDetectorInterface.h", "_speech_detector_interface_8h.html", "_speech_detector_interface_8h" ]
];