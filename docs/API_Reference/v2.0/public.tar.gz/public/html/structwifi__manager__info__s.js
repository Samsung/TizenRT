var structwifi__manager__info__s =
[
    [ "mac_address", "structwifi__manager__info__s.html#ac73e8daad37eadc069ea056a686ea604", null ]
];