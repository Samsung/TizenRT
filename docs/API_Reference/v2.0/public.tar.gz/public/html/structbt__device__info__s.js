var structbt__device__info__s =
[
    [ "bt_class", "structbt__device__info__s.html#adf8042e756ad934edfc47b038334a92c", null ],
    [ "is_authorized", "structbt__device__info__s.html#ad737bafb0991cfe7c36ccd9d2516a129", null ],
    [ "is_bonded", "structbt__device__info__s.html#a75d12d95b85f9a7a1814534fafdbdd82", null ],
    [ "is_connected", "structbt__device__info__s.html#a5995db87b2ef40e52a47d2fb1f13ae42", null ],
    [ "manufacturer_data", "structbt__device__info__s.html#a1fa2f949739a66f8b4c052c7685c82fa", null ],
    [ "manufacturer_data_len", "structbt__device__info__s.html#abb0dc19d8a41b0986d130c139dd95614", null ],
    [ "remote_address", "structbt__device__info__s.html#a7cb374ca04ac60371bf1428c9f154890", null ],
    [ "remote_name", "structbt__device__info__s.html#a4cd9a62ec7e9a8a2dd0ab9edd782b2a4", null ],
    [ "service_count", "structbt__device__info__s.html#aa20c27a9adf408745c89d11e6ec54ed5", null ],
    [ "service_uuid", "structbt__device__info__s.html#acac7c855441ca3239a09a49918adcaf5", null ]
];