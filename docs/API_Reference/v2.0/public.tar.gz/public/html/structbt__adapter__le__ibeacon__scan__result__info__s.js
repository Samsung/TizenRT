var structbt__adapter__le__ibeacon__scan__result__info__s =
[
    [ "company_id", "structbt__adapter__le__ibeacon__scan__result__info__s.html#ac1a52f137d4146c06a09ce13feff07fa", null ],
    [ "ibeacon_type", "structbt__adapter__le__ibeacon__scan__result__info__s.html#a1fba4ea9271b1b5f65dc9709a14c66f6", null ],
    [ "major_id", "structbt__adapter__le__ibeacon__scan__result__info__s.html#a4d4b96b48dd9c7d241e880a4a5787f1f", null ],
    [ "measured_power", "structbt__adapter__le__ibeacon__scan__result__info__s.html#ac73384c8e9ca7f365256cc24ea87c09a", null ],
    [ "minor_id", "structbt__adapter__le__ibeacon__scan__result__info__s.html#ac763e93541d75ded32d00c03dcebcbd8", null ],
    [ "uuid", "structbt__adapter__le__ibeacon__scan__result__info__s.html#a175104963afffa60db43111a661ddbc2", null ]
];