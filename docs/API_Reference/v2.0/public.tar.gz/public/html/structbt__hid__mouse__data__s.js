var structbt__hid__mouse__data__s =
[
    [ "axis_x", "structbt__hid__mouse__data__s.html#a4b8ac8664e6a624b254f6a67538475fc", null ],
    [ "axis_y", "structbt__hid__mouse__data__s.html#a7219e7e924f0cb8c5826ff3994222fd3", null ],
    [ "buttons", "structbt__hid__mouse__data__s.html#ab25f60de6d1c5f370231402aa1097c95", null ],
    [ "padding", "structbt__hid__mouse__data__s.html#a78dca952886227190969e885fbdd4fb4", null ]
];