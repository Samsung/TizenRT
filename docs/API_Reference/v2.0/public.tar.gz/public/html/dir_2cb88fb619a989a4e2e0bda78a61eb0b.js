var dir_2cb88fb619a989a4e2e0bda78a61eb0b =
[
    [ "task_manager.h", "task__manager_8h.html", "task__manager_8h" ],
    [ "task_manager_broadcast_list.h", "task__manager__broadcast__list_8h.html", "task__manager__broadcast__list_8h" ]
];