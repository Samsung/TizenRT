var globals_func =
[
    [ "b", "globals_func.html", null ],
    [ "c", "globals_func_c.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "e", "globals_func_e.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "p", "globals_func_p.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ],
    [ "w", "globals_func_w.html", null ]
];