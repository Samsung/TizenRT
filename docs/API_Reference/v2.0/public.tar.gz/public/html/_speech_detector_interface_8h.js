var _speech_detector_interface_8h =
[
    [ "SpeechDetectorInterface", "classmedia_1_1voice_1_1_speech_detector_interface.html", null ]
];