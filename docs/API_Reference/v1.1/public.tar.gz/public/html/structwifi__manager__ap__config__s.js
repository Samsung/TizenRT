var structwifi__manager__ap__config__s =
[
    [ "ap_auth_type", "structwifi__manager__ap__config__s.html#a8264dd8fa95ff226a79c69d534f5cb9b", null ],
    [ "ap_crypto_type", "structwifi__manager__ap__config__s.html#ae523c7d21f7c77ada0dafb27d60a6b94", null ],
    [ "passphrase", "structwifi__manager__ap__config__s.html#a618956d9d1895c235e787737ce4a6110", null ],
    [ "passphrase_length", "structwifi__manager__ap__config__s.html#a452f9333f2ffe265f9cfa6a250aa28e6", null ],
    [ "ssid", "structwifi__manager__ap__config__s.html#ad254d41fb741fd973215d202786b5737", null ],
    [ "ssid_length", "structwifi__manager__ap__config__s.html#a49344806e45e76840aa974e5063c9d58", null ]
];