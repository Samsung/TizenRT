var group___i_o_t_b_u_s =
[
    [ "GPIO", "group___g_p_i_o.html", "group___g_p_i_o" ],
    [ "I2C", "group___i2_c.html", "group___i2_c" ],
    [ "PWM", "group___p_w_m.html", "group___p_w_m" ],
    [ "SPI", "group___s_p_i.html", "group___s_p_i" ],
    [ "UART", "group___u_a_r_t.html", "group___u_a_r_t" ],
    [ "iotbus_error.h", "iotbus__error_8h.html", null ],
    [ "iotbus_error_e", "group___i_o_t_b_u_s.html#ga05ca8b1e4de0a7f08ed55ae0c588157c", null ]
];