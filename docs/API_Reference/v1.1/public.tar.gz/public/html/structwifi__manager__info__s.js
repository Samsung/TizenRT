var structwifi__manager__info__s =
[
    [ "mac_address", "structwifi__manager__info__s.html#a1b7a913f00654bee8ef29c8fb8872e06", null ]
];