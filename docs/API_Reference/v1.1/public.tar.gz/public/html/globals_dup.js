var globals_dup =
[
    [ "c", "globals.html", null ],
    [ "d", "globals_d.html", null ],
    [ "i", "globals_i.html", null ],
    [ "m", "globals_m.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ],
    [ "w", "globals_w.html", null ]
];