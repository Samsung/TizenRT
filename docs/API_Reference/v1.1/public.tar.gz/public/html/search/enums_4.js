var searchData=
[
  ['pcm_5fformat',['pcm_format',['../group___tiny_alsa.html#ga22e51d330d677c2ea6c24cd5ce051535',1,'tinyalsa.h']]],
  ['pcm_5fparam',['pcm_param',['../group___tiny_alsa.html#gaadf7d7c28315ece342d6281f31b9b69d',1,'tinyalsa.h']]]
];
