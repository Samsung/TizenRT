var searchData=
[
  ['client_5finfo_5fs',['client_info_s',['../structclient__info__s.html',1,'']]]
];
