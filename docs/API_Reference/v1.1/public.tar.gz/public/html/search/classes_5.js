var searchData=
[
  ['server_5finfo_5fs',['server_info_s',['../structserver__info__s.html',1,'']]]
];
