var searchData=
[
  ['tinyalsa_2eh',['tinyalsa.h',['../tinyalsa_8h.html',1,'']]]
];
