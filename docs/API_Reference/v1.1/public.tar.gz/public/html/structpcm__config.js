var structpcm__config =
[
    [ "channels", "structpcm__config.html#a9ed2af39747c91928713f96d4e28b53f", null ],
    [ "format", "structpcm__config.html#a3fa45ac469c7d729ccc263914de71e96", null ],
    [ "period_count", "structpcm__config.html#a69331f21b4dfe981c9e6d1a027b8c755", null ],
    [ "period_size", "structpcm__config.html#a051e413600f0ac702820c15386dd9062", null ],
    [ "rate", "structpcm__config.html#adf42a979321286885fe5a447d48d14d6", null ],
    [ "silence_threshold", "structpcm__config.html#a46ab747e08f8a9e23484a31cf8898a7c", null ],
    [ "start_threshold", "structpcm__config.html#afaf05006c155615ab84e21b8813afb1d", null ],
    [ "stop_threshold", "structpcm__config.html#a583745818fd2c7f7531834b30661aeb0", null ]
];