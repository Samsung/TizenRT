var group___wi__fi___manager =
[
    [ "wifi_manager.h", "wifi__manager_8h.html", null ],
    [ "wifi_manager_scan_info_s", "structwifi__manager__scan__info__s.html", null ],
    [ "wifi_manager_cb_s", "structwifi__manager__cb__s.html", null ],
    [ "wifi_manager_info_s", "structwifi__manager__info__s.html", [
      [ "mac_address", "structwifi__manager__info__s.html#a1b7a913f00654bee8ef29c8fb8872e06", null ]
    ] ],
    [ "wifi_manager_softap_config_s", "structwifi__manager__softap__config__s.html", null ],
    [ "wifi_manager_ap_config_s", "structwifi__manager__ap__config__s.html", [
      [ "ap_auth_type", "structwifi__manager__ap__config__s.html#a8264dd8fa95ff226a79c69d534f5cb9b", null ],
      [ "ap_crypto_type", "structwifi__manager__ap__config__s.html#ae523c7d21f7c77ada0dafb27d60a6b94", null ],
      [ "passphrase", "structwifi__manager__ap__config__s.html#a618956d9d1895c235e787737ce4a6110", null ],
      [ "passphrase_length", "structwifi__manager__ap__config__s.html#a452f9333f2ffe265f9cfa6a250aa28e6", null ],
      [ "ssid", "structwifi__manager__ap__config__s.html#ad254d41fb741fd973215d202786b5737", null ],
      [ "ssid_length", "structwifi__manager__ap__config__s.html#a49344806e45e76840aa974e5063c9d58", null ]
    ] ],
    [ "connect_status_e", "group___wi-_fi___manager.html#gab7905416d1fb59ca87256bdc1ad4764b", null ],
    [ "wifi_manager_ap_auth_type_e", "group___wi-_fi___manager.html#ga7d35538c0eb7647b2c480dd67be44371", [
      [ "WIFI_MANAGER_AUTH_OPEN", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371a21369e20a6a4c6896b05da21d9a52fd4", null ],
      [ "WIFI_MANAGER_AUTH_WEP_SHARED", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371a98f2b069d8e07ac922c0093c5b4b4efb", null ],
      [ "WIFI_MANAGER_AUTH_WPA_PSK", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371a79185a883e32c42070e91c4be81d4e28", null ],
      [ "WIFI_MANAGER_AUTH_WPA2_PSK", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371ab582e4ee357a5e15f31bba89423d405b", null ],
      [ "WIFI_MANAGER_AUTH_WPA_AND_WPA2_PSK", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371ab7792f81a9e7f0a5b30611f987570cbb", null ],
      [ "WIFI_MANAGER_AUTH_UNKNOWN", "group___wi-_fi___manager.html#gga7d35538c0eb7647b2c480dd67be44371a7afcb6cebfa9ce4938bfefa92e130da5", null ]
    ] ],
    [ "wifi_manager_ap_crypto_type_e", "group___wi-_fi___manager.html#gae2c4967c98ed509c8b660d49a82b26cf", [
      [ "WIFI_MANAGER_CRYPTO_NONE", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfab72264aa4a336576aea12b4b371e4783", null ],
      [ "WIFI_MANAGER_CRYPTO_WEP_64", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfa13d59073e0a3933fe2fdf93a7995b631", null ],
      [ "WIFI_MANAGER_CRYPTO_WEP_128", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfa09e96e832810df72e504269b6f0a9684", null ],
      [ "WIFI_MANAGER_CRYPTO_AES", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfa9c4ba91c21408bb2a5bbf8332f602c08", null ],
      [ "WIFI_MANAGER_CRYPTO_TKIP", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfafc3b3d08b38bd373b58690d1b69b675c", null ],
      [ "WIFI_MANAGER_CRYPTO_TKIP_AND_AES", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfa239857c10bc5808a436e6c3a530a11d7", null ],
      [ "WIFI_MANAGER_CRYPTO_UNKNOWN", "group___wi-_fi___manager.html#ggae2c4967c98ed509c8b660d49a82b26cfac436b8e0b4719ac15c131435b9e699d2", null ]
    ] ],
    [ "wifi_manager_mode_e", "group___wi-_fi___manager.html#gab6ac98a210a8d20c519f2c75bdb6e55b", null ],
    [ "wifi_manager_result_e", "group___wi-_fi___manager.html#ga21f701dbc0af2aa6ede8bba73ceb9edf", null ],
    [ "wifi_manager_scan_result_e", "group___wi-_fi___manager.html#gadd72564b9da6dc144a8fe6f560434c73", null ],
    [ "wifi_manager_connect_ap", "group___wi-_fi___manager.html#ga8f70e50e98aa9b7b2d4b867ee740556d", null ],
    [ "wifi_manager_deinit", "group___wi-_fi___manager.html#gac970ea8250ccd7698fcf73d88dc088d4", null ],
    [ "wifi_manager_disconnect_ap", "group___wi-_fi___manager.html#gaaa2ee756eef93c2651ebf47467b5a25b", null ],
    [ "wifi_manager_get_info", "group___wi-_fi___manager.html#gacebe75c0fce291c2e3ca3d9e3e9bbbe1", null ],
    [ "wifi_manager_init", "group___wi-_fi___manager.html#gaf26cf2debf241a7af57082f158531a83", null ],
    [ "wifi_manager_scan_ap", "group___wi-_fi___manager.html#ga854b67449d5c1f58e582662638e63afb", null ],
    [ "wifi_manager_set_mode", "group___wi-_fi___manager.html#ga9b3d8ee066819d0779403b0434d3455f", null ]
];