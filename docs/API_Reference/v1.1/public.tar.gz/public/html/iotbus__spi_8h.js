var iotbus__spi_8h =
[
    [ "iotbus_spi_context_h", "group___s_p_i.html#gac99b32486d9e86b9112d015972d4b984", null ],
    [ "iotbus_spi_mode_e", "group___s_p_i.html#ga80658801a39a1cc6afef5192a320b6df", null ],
    [ "iotbus_spi_close", "group___s_p_i.html#ga262f23eee62fca4be77a1eee609854cf", null ],
    [ "iotbus_spi_open", "group___s_p_i.html#ga7dd00e8f4bdc4a6867a6053fd26a712b", null ],
    [ "iotbus_spi_recv", "group___s_p_i.html#ga40540293d7b1d5d7cca612ecc38fe9dd", null ],
    [ "iotbus_spi_transfer_buf", "group___s_p_i.html#ga87176af3f1575cf6d33a2ae4c76d449f", null ],
    [ "iotbus_spi_write", "group___s_p_i.html#ga8d9c5d9e36291b1e1cc1d4564148a13f", null ]
];