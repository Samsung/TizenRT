/****************************************************************************
 *
 * Copyright 2016 Samsung Electronics All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 ****************************************************************************/

/******************************************************************************
 * Included Files
 *****************************************************************************/

#include <stdio.h>
#include <errno.h>
#include <debug.h>

#include <tinyara/kmalloc.h>
#include <stm32_gpio.h>

#include "mikroequail_gpio.h"

#ifdef CONFIG_GPIO

/******************************************************************************
 * Private Types
 *****************************************************************************/

/* This describes mikroequail board gpio private structure */

struct mikroequail_gpio_priv_s {
	uint16_t g_num;				/* global gpio number for iot bus API usage */
	uint16_t int_event_status;	/* even & int status for gpio */
	uint32_t port_pin;			/* Stm32 Port and pin info */
	uint32_t pincfgset;			/* Current pin cfg */
	gpio_direciton_t dir;		/* curernt dir */
	gpio_edge_t edge;			/* current edge */
	gpio_drive_t drive;			/* current drive */
	xcpt_t func;				/* int cb function */
};

/* This describes mikroequail board gpio table */

struct mikroequail_gpio_table_type {
	uint32_t port_pin;
	xcpt_t int_cbfunc;
};

/******************************************************************************
 * Private Function Prototypes
 *****************************************************************************/

static void mikroequail_gpio_enable_irq(struct gpio_dev_s *dev, gpio_edge_t edge);

static void mikroequail_gpio_disable_irq(struct gpio_dev_s *dev);

static int mikroequail_gpio_ctrl(struct gpio_dev_s *dev, int cmd, unsigned long args);

static int mikroequail_gpio_get(struct gpio_dev_s *dev);

static void mikroequail_gpio_set(struct gpio_dev_s *dev, unsigned int value);

static int mikroequail_gpio_close(struct gpio_dev_s *dev);

static int mikroequail_gpio_open(struct gpio_dev_s *dev);

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SPI)
static int gpio_porta_pin1_int_cb(int irq, void *context);

static int gpio_porta_pin2_int_cb(int irq, void *context);

static int gpio_porta_pin3_int_cb(int irq, void *context);
#endif

static int gpio_porta_pin4_int_cb(int irq, void *context);

static int gpio_porta_pin5_int_cb(int irq, void *context);

static int gpio_porta_pin6_int_cb(int irq, void *context);

static int gpio_porta_pin7_int_cb(int irq, void *context);

#if !defined(CONFIG_STM32_USART1)
static int gpio_porta_pin9_int_cb(int irq, void *context);

static int gpio_porta_pin10_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
static int gpio_porta_pin14_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_SPI1)
static int gpio_portb_pin3_int_cb(int irq, void *context);

static int gpio_portb_pin4_int_cb(int irq, void *context);

static int gpio_portb_pin5_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_I2C1)
static int gpio_portb_pin6_int_cb(int irq, void *context);

static int gpio_portb_pin7_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
static int gpio_portb_pin9_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_USART6)
static int gpio_portc_pin6_int_cb(int irq, void *context);

static int gpio_portc_pin7_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
static int gpio_portc_pin8_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_SPI3)
static int gpio_portc_pin10_int_cb(int irq, void *context);

static int gpio_portc_pin11_int_cb(int irq, void *context);

static int gpio_portc_pin12_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
static int gpio_portd_pin0_int_cb(int irq, void *context);

static int gpio_portd_pin1_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_USART2)
static int gpio_portd_pin5_int_cb(int irq, void *context);

static int gpio_portd_pin6_int_cb(int irq, void *context);
#endif

#if !defined(CONFIG_STM32_USART3)
static int gpio_portd_pin8_int_cb(int irq, void *context);

static int gpio_portd_pin9_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
static int gpio_portd_pin11_int_cb(int irq, void *context);

static int gpio_portd_pin12_int_cb(int irq, void *context);
#endif

static int gpio_portd_pin13_int_cb(int irq, void *context);

static int gpio_portd_pin14_int_cb(int irq, void *context);

#if !(CONFIG_STM32_TIM4_CHANNEL == 4)
static int gpio_portd_pin15_int_cb(int irq, void *context);
#endif

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
static int gpio_porte_pin0_int_cb(int irq, void *context);

static int gpio_porte_pin1_int_cb(int irq, void *context);
#endif

#if !(CONFIG_STM32_TIM1_CHANNEL == 1)
static int gpio_porte_pin9_int_cb(int irq, void *context);
#endif

/******************************************************************************
 * Private Data
 *****************************************************************************/

/* static gpios table data */

static const struct mikroequail_gpio_table_type g_board_gpios_tbl[MIKROE_QUAIL_BOARD_GPIOS_COUNT] = {
	/* PORT A Initial PIN CFG set , cb function ptr */
#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SPI)
	{GPIO_PORTA | GPIO_PIN1, gpio_porta_pin1_int_cb},
	{GPIO_PORTA | GPIO_PIN2, gpio_porta_pin2_int_cb},
	{GPIO_PORTA | GPIO_PIN3, gpio_porta_pin3_int_cb},
#endif

	{GPIO_PORTA | GPIO_PIN4, gpio_porta_pin4_int_cb},
	{GPIO_PORTA | GPIO_PIN5, gpio_porta_pin5_int_cb},
	{GPIO_PORTA | GPIO_PIN6, gpio_porta_pin6_int_cb},
	{GPIO_PORTA | GPIO_PIN7, gpio_porta_pin7_int_cb},

#if !defined(CONFIG_STM32_USART1)
	{GPIO_PORTA | GPIO_PIN9, gpio_porta_pin9_int_cb},
	{GPIO_PORTA | GPIO_PIN10, gpio_porta_pin10_int_cb},
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
	{GPIO_PORTA | GPIO_PIN14, gpio_porta_pin14_int_cb},
#endif

	/* PORT B Initial PIN CFG set , cb function ptr */
#if !defined(CONFIG_STM32_SPI1)
	{GPIO_PORTB | GPIO_PIN3, gpio_portb_pin3_int_cb},
	{GPIO_PORTB | GPIO_PIN4, gpio_portb_pin4_int_cb},
	{GPIO_PORTB | GPIO_PIN5, gpio_portb_pin5_int_cb},
#endif

#if !defined(CONFIG_STM32_I2C1)
	{GPIO_PORTB | GPIO_PIN6, gpio_portb_pin6_int_cb},
	{GPIO_PORTB | GPIO_PIN7, gpio_portb_pin7_int_cb},
#endif

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
	{GPIO_PORTB | GPIO_PIN9, gpio_portb_pin9_int_cb},
#endif

	/* PORT C Initial PIN CFG set , cb function ptr */
#if !defined(CONFIG_STM32_USART6)
	{GPIO_PORTC | GPIO_PIN6, gpio_portc_pin6_int_cb},
	{GPIO_PORTC | GPIO_PIN7, gpio_portc_pin7_int_cb},
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
	{GPIO_PORTC | GPIO_PIN8, gpio_portc_pin8_int_cb},
#endif

#if !defined(CONFIG_STM32_SPI3)
	{GPIO_PORTC | GPIO_PIN10, gpio_portc_pin10_int_cb},
	{GPIO_PORTC | GPIO_PIN11, gpio_portc_pin11_int_cb},
	{GPIO_PORTC | GPIO_PIN12, gpio_portc_pin12_int_cb},
#endif

	/* PORT D Initial PIN CFG set , cb function ptr */
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
	{GPIO_PORTD | GPIO_PIN0, gpio_portd_pin0_int_cb},
	{GPIO_PORTD | GPIO_PIN1, gpio_portd_pin1_int_cb},
#endif

#if !defined(CONFIG_STM32_USART2)
	{GPIO_PORTD | GPIO_PIN5, gpio_portd_pin5_int_cb},
	{GPIO_PORTD | GPIO_PIN6, gpio_portd_pin6_int_cb},
#endif

#if !defined(CONFIG_STM32_USART3)
	{GPIO_PORTD | GPIO_PIN8, gpio_portd_pin8_int_cb},
	{GPIO_PORTD | GPIO_PIN9, gpio_portd_pin9_int_cb},
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
	{GPIO_PORTD | GPIO_PIN11, gpio_portd_pin11_int_cb},
	{GPIO_PORTD | GPIO_PIN12, gpio_portd_pin12_int_cb},
#endif

	{GPIO_PORTD | GPIO_PIN13, gpio_portd_pin13_int_cb},
	{GPIO_PORTD | GPIO_PIN14, gpio_portd_pin14_int_cb},

#if !(CONFIG_STM32_TIM4_CHANNEL == 4)
	{GPIO_PORTD | GPIO_PIN15, gpio_portd_pin15_int_cb},

#endif

	/* PORT E Initial PIN CFG set , cb function ptr */
#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
	{GPIO_PORTE | GPIO_PIN0, gpio_porte_pin0_int_cb},
	{GPIO_PORTE | GPIO_PIN1, gpio_porte_pin1_int_cb},
#endif

#if !(CONFIG_STM32_TIM1_CHANNEL == 1)
	{GPIO_PORTE | GPIO_PIN9, gpio_porte_pin9_int_cb},
#endif
};

/*board gpios dev ops table data */

static struct gpio_dev_s mikroequail_gpio[MIKROE_QUAIL_BOARD_GPIOS_COUNT];

/*board gpio ops table */

static const struct gpio_ops_s mikroequail_gpio_ops = {
	.open = mikroequail_gpio_open,
	.close = mikroequail_gpio_close,
	.set = mikroequail_gpio_set,
	.get = mikroequail_gpio_get,
	.ctrl = mikroequail_gpio_ctrl,
};

/******************************************************************************
 * Private Functions
 *****************************************************************************/

/*******************************************************************************
 * Name: mikroequail_gpio_irq_handler
 *
 * Description:
 *  Mikro-E Quail board GPIOs common interrupt service handler for IOT BUS APIs
 *
 ******************************************************************************/
static void mikroequail_gpio_irq_handler(uint8_t idx)
{
	gpio_notify(&mikroequail_gpio[idx]);

}

/*******************************************************************************
 * Name: gpio_porta_pinX
 *
 * Description:
 *   Mikro-e-Quail Board (STM32 PORT A)- GPIOs INT/Event Call back functions
 *
 ******************************************************************************/

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SPI)

static int gpio_porta_pin1_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN1);
	return OK;
}

static int gpio_porta_pin2_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN2);
	return OK;
}

static int gpio_porta_pin3_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN3);
	return OK;
}

#endif

static int gpio_porta_pin4_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN4);
	return OK;
}

static int gpio_porta_pin5_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN5);
	return OK;
}

static int gpio_porta_pin6_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN6);
	return OK;
}

static int gpio_porta_pin7_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN7);
	return OK;
}

#if !defined(CONFIG_STM32_USART1)
static int gpio_porta_pin9_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN9);
	return OK;
}

static int gpio_porta_pin10_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN10);
	return OK;
}
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
static int gpio_porta_pin14_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTA_PIN14);
	return OK;
}
#endif

/*******************************************************************************
 * Name: gpio_portb_pinX
 *
 * Description:
 *   Mikro-e-Quail Board (STM32 PORT B)- GPIOs INT/Event Call back functions
 *
 ******************************************************************************/

#if !defined(CONFIG_STM32_SPI1)
static int gpio_portb_pin3_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN3);
	return OK;
}

static int gpio_portb_pin4_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN4);
	return OK;
}

static int gpio_portb_pin5_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN5);
	return OK;
}
#endif

#if !defined(CONFIG_STM32_I2C1)
static int gpio_portb_pin6_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN6);
	return OK;
}

static int gpio_portb_pin7_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN7);
	return OK;
}
#endif

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
static int gpio_portb_pin9_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTB_PIN9);
	return OK;
}
#endif

/*******************************************************************************
 * Name: gpio_portc_pinX
 *
 * Description:
 *   Mikro-e-Quail Board (STM32 PORT C)- GPIOs INT/Event Call back functions
 *
 ******************************************************************************/

#if !defined(CONFIG_STM32_USART6)
static int gpio_portc_pin6_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN6);
	return OK;
}

static int gpio_portc_pin7_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN7);
	return OK;
}
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
static int gpio_portc_pin8_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN8);
	return OK;
}
#endif

#if !defined(CONFIG_STM32_SPI3)
static int gpio_portc_pin10_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN10);
	return OK;
}

static int gpio_portc_pin11_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN11);
	return OK;
}

static int gpio_portc_pin12_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTC_PIN12);
	return OK;
}
#endif

/*******************************************************************************
 * Name: gpio_portd_pinX
 *
 * Description:
 *   Mikro-e-Quail Board (STM32 PORT D)- GPIOs INT/Event Call back functions
 *
 ******************************************************************************/
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
static int gpio_portd_pin0_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN0);
	return OK;
}

static int gpio_portd_pin1_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN1);
	return OK;
}
#endif

#if !defined(CONFIG_STM32_USART2)
static int gpio_portd_pin5_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN5);
	return OK;
}

static int gpio_portd_pin6_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN6);
	return OK;
}
#endif

#if !defined(CONFIG_STM32_USART3)
static int gpio_portd_pin8_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN8);
	return OK;
}

static int gpio_portd_pin9_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN9);
	return OK;
}
#endif

#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
static int gpio_portd_pin11_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN11);
	return OK;
}

static int gpio_portd_pin12_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN12);
	return OK;
}
#endif

static int gpio_portd_pin13_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN13);
	return OK;
}

static int gpio_portd_pin14_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN14);
	return OK;
}

#if !(CONFIG_STM32_TIM4_CHANNEL == 4)
static int gpio_portd_pin15_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTD_PIN15);
	return OK;
}
#endif

/*******************************************************************************
 * Name: gpio_porte_pinX
 *
 * Description:
 *   Mikro-e-Quail Board (STM32 PORT E)-INT/Event Call back functions
 *
 ******************************************************************************/

#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
static int gpio_porte_pin0_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTE_PIN0);
	return OK;
}

static int gpio_porte_pin1_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTE_PIN1);
	return OK;
}
#endif

#if !(CONFIG_STM32_TIM1_CHANNEL == 1)
static int gpio_porte_pin9_int_cb(int irq, void *context)
{
	mikroequail_gpio_irq_handler(GPIO_PORTE_PIN9);
	return OK;
}
#endif

/*******************************************************************************
 * Name: mikroequail_gpio_disable_irq
 *
 * Description:
 *   Disable GPIO interrupt
 *
 ******************************************************************************/

static void mikroequail_gpio_disable_irq(struct gpio_dev_s *dev)
{
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;
	if (priv->int_event_status == GPIO_INT_EVENT_SET) {
		stm32_gpiosetevent(priv->pincfgset, false, false, false, NULL);
		priv->edge = GPIO_EDGE_NONE;
		priv->int_event_status = GPIO_INT_EVENT_STATUS_NONE;
	}

}

/*******************************************************************************
 * Name: mikroequail_gpio_enable_irq
 *
 * Description:
 *   Enable GPIO interrupt
 *
 ******************************************************************************/

static void mikroequail_gpio_enable_irq(struct gpio_dev_s *dev, gpio_edge_t edge)
{
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;
	switch (edge) {
	case GPIO_EDGE_RISING:
		stm32_gpiosetevent(priv->pincfgset, true, false, true, priv->func);
		priv->int_event_status = GPIO_INT_EVENT_SET;
		priv->edge = GPIO_EDGE_RISING;
		break;
	case GPIO_EDGE_FALLING:
		stm32_gpiosetevent(priv->pincfgset, false, true, true, priv->func);
		priv->int_event_status = GPIO_INT_EVENT_SET;
		priv->edge = GPIO_EDGE_FALLING;
		break;

	case GPIO_EDGE_BOTH:
		stm32_gpiosetevent(priv->pincfgset, true, true, true, priv->func);
		priv->int_event_status = GPIO_INT_EVENT_SET;
		priv->edge = GPIO_EDGE_BOTH;
		break;
	default:
		break;
	}

}

/*******************************************************************************
 * Name: mikroequail_gpio_open
 *
 * Description:
 *  open gpio
 *
 ******************************************************************************/

static int mikroequail_gpio_open(struct gpio_dev_s *dev)
{
	int ret;
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;

	/* By default GPIO type is set as GPIO_OUTPUT and type is set as
	 * GPIO_PUSHPULL */
	/* This is as per IOT IO BUS API requirment, if any change in this below code
	 * need to be changed */
	priv->pincfgset = priv->port_pin | GPIO_PUSHPULL | GPIO_OUTPUT | GPIO_SPEED_50MHz;

	ret = stm32_configgpio(priv->pincfgset);

	if (ret < 0) {
		return ERROR;
	}

	return OK;
}

/*******************************************************************************
 * Name: mikroequail_gpio_close
 *
 * Description:
 *  close gpio
 *
 ******************************************************************************/

static int mikroequail_gpio_close(struct gpio_dev_s *dev)
{
	int ret;
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;

	mikroequail_gpio_disable_irq(dev);

	/* Make GPIO as INPUT while closing it, this would avoid leakage current */
	priv->pincfgset = priv->port_pin | GPIO_INPUT;

	ret = stm32_configgpio(priv->pincfgset);

	if (ret < 0) {
		return ERROR;
	}

	return OK;
}

/*******************************************************************************
 * Name: mikroequail_gpio_set
 *
 * Description:
 *   Set GPIO output value. GPIO pin is basically configured in/out mode.
 *   So you don't need to change the direction if you want to use in mode.
 *   And any nonzero value is treated as high.
 *
 ******************************************************************************/

static void mikroequail_gpio_set(struct gpio_dev_s *dev, unsigned int value)
{
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;

	dbg("(%d)(%d)\n", priv->pincfgset, value);

	stm32_gpiowrite(priv->pincfgset, value);

}

/*******************************************************************************
 * Name: mikroequail_gpio_get
 *
 * Description:
 *   Get GPIO value.
 *
 ******************************************************************************/

static int mikroequail_gpio_get(struct gpio_dev_s *dev)
{
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;

	dbg("(%d)\n", priv->pincfgset);

	return stm32_gpioread(priv->pincfgset);
}

/*******************************************************************************
 * Name: mikroequail_gpio_ctrl
 *
 * Description:
 *   This function exists only if the pin can be configured as an interrupt
 *   generating input pin.
 *
 ******************************************************************************/

static int mikroequail_gpio_ctrl(struct gpio_dev_s *dev, int cmd, unsigned long args)
{
	int ret = OK;
	struct mikroequail_gpio_priv_s *priv = (struct mikroequail_gpio_priv_s *)dev->priv;

	dbg("(%d) \n", cmd);

	switch (cmd) {
	case GPIO_CMD_SET_DIRECTION:
		switch (args) {
		case GPIO_DIRECTION_OUT:
			priv->pincfgset = priv->port_pin | GPIO_OUTPUT | GPIO_SPEED_50MHz;
			priv->dir = GPIO_DIRECTION_OUT;
			break;

		case GPIO_DIRECTION_IN:
			priv->pincfgset = priv->port_pin | GPIO_INPUT | GPIO_SPEED_50MHz;
			priv->dir = GPIO_DIRECTION_IN;
			break;
		case GPIO_DIRECTION_NONE:
			/* Direction NONE is mapped as default GPIO cfg in STM32 CPU */
			priv->pincfgset = priv->port_pin | GPIO_INPUT;
			priv->dir = GPIO_DIRECTION_NONE;
			break;
		}
		stm32_configgpio(priv->pincfgset);
		break;

	case GPIO_CMD_GET_DIRECTION:
		ret = priv->dir;
		break;

	case GPIO_CMD_SET_EDGE:
		switch (args) {
		case GPIO_EDGE_NONE:
			mikroequail_gpio_disable_irq(dev);
			break;
		case GPIO_EDGE_RISING:
		case GPIO_EDGE_FALLING:
		case GPIO_EDGE_BOTH:
			mikroequail_gpio_enable_irq(dev, args);
			break;
		case GPIO_LEVEL_LOW:
		case GPIO_LEVEL_HIGH:
		default:
			dbg("Unsupported Edge Type (%d)\n", args);
			ret = -EINVAL;
			break;
		}
		break;

	case GPIO_CMD_GET_EDGE:
		ret = (int)priv->edge;
		break;

	case GPIO_CMD_SET_DRIVE:
		switch (args) {
		case GPIO_DRIVE_PULLUP:
			priv->pincfgset &= ~GPIO_PUPD_MASK;
			priv->pincfgset = priv->pincfgset | GPIO_PULLUP;
			priv->drive = GPIO_DRIVE_PULLUP;
			break;
		case GPIO_DRIVE_PULLDOWN:
			priv->pincfgset &= ~GPIO_PUPD_MASK;
			priv->pincfgset = priv->pincfgset | GPIO_PULLDOWN;
			priv->drive = GPIO_DRIVE_PULLDOWN;
			break;
		case GPIO_DRIVE_FLOAT:
			priv->pincfgset &= ~GPIO_PUPD_MASK;
			priv->pincfgset = priv->pincfgset | GPIO_FLOAT;
			priv->drive = GPIO_DRIVE_FLOAT;
			break;
		case GPIO_DRIVE_PUSHPULL:
			/* clear drive mask and set Push pull */
			priv->pincfgset &= ~GPIO_PUPD_MASK;
			priv->drive = GPIO_DRIVE_PUSHPULL;
			break;
		/* case GPIO_DRIVE_OPENDRAIN: */
		case GPIO_DRIVE_NONE:
			priv->pincfgset &= ~GPIO_PUPD_MASK;
			priv->drive = GPIO_DRIVE_NONE;
			break;
		}
		stm32_configgpio(priv->pincfgset);
		break;

	case GPIO_CMD_GET_DRIVE:
		ret = (int)priv->drive;
		break;

	default:
		dbg("Unsupported Command(%d)\n", cmd);
		ret = -EPERM;
		break;
	}

	return ret;
}

/*******************************************************************************
 * Name: up_create_gpio
 *
 * Description:
 * Create device. Userspace may ask the kernel to export control of
 *  a GPIO to userspace by writing its number to file (gpio_export).
 *
 ******************************************************************************/

int register_gpio(int32_t idx)
{
	char path[16];
	int ret;
	struct mikroequail_gpio_priv_s *priv;

	if (idx < 0 || idx >= MIKROE_QUAIL_BOARD_GPIOS_COUNT) {
		return -ENODEV;
	}

	if (mikroequail_gpio[idx].priv) {
		return -EBUSY;
	}

	if (!(priv = kmm_malloc(sizeof(struct mikroequail_gpio_priv_s)))) {
		return -ENOMEM;
	}

	priv->g_num = idx;
	priv->int_event_status = GPIO_INT_EVENT_STATUS_NONE;
	priv->port_pin = g_board_gpios_tbl[idx].port_pin;
	priv->pincfgset = GPIO_PIN_CFG_NONE;
	priv->dir = GPIO_DIRECTION_NONE;
	priv->edge = GPIO_EDGE_NONE;
	priv->drive = GPIO_DRIVE_NONE;
	priv->func = g_board_gpios_tbl[idx].int_cbfunc;

	mikroequail_gpio[idx].priv = priv;
	mikroequail_gpio[idx].ops = &(mikroequail_gpio_ops);

	snprintf(path, sizeof(path), "/dev/gpio%d", idx);

	ret = gpio_register(path, &mikroequail_gpio[idx]);
	if (ret < 0) {
		dbg(" Gpio[%d] register failed: %d\n", idx, ret);
	}

	return OK;
}

/******************************************************************************
 * Public Functions
 ******************************************************************************/

/*******************************************************************************
 * Name: up_destroy_gpio
 *
 * Description:
 *  Destroy device.
 *
 ******************************************************************************/

int up_destroy_gpio(int32_t idx)
{
	char path[16];
	struct mikroequail_gpio_priv_s *priv;

	if (idx < 0 || idx >= MIKROE_QUAIL_BOARD_GPIOS_COUNT) {
		return -ENODEV;
	}

	if (!mikroequail_gpio[idx].priv) {
		return -ENODEV;
	}

	priv = (struct mikroequail_gpio_priv_s *)mikroequail_gpio[idx].priv;

	priv->pincfgset = priv->pincfgset | GPIO_INPUT;

	stm32_configgpio(priv->pincfgset);

	/* disable irq */
	if (priv->int_event_status) {
		mikroequail_gpio_disable_irq(&mikroequail_gpio[idx]);
	}

	/* free memory */

	kmm_free(mikroequail_gpio[idx].priv);

	/* re-initialize */
	mikroequail_gpio[idx].priv = NULL;
	mikroequail_gpio[idx].ops = NULL;

	/* remote file(device) */

#ifndef CONFIG_GPIO_EXPORT
	snprintf(path, sizeof(path), "/dev/gpio%d", idx);
	unregister_driver(path);
#endif

	return 0;
}

/*******************************************************************************
 * Name: up_gpioinitialize
 *
 * Description:
 *  Initialize GPIO. This function is called during system initialization.
 *
 ******************************************************************************/

void up_gpioinitialize(void)
{
	uint8_t idx;
	uint32_t ret;

#ifndef CONFIG_GPIO_EXPORT
	for (idx = 0; idx < MIKROE_QUAIL_BOARD_GPIOS_COUNT; idx++) {
		mikroequail_gpio[idx].priv = NULL;
		mikroequail_gpio[idx].ops = NULL;

		ret = register_gpio(idx);
		if (ret != OK) {
			dbg("can't create gpio(%d)\n", idx);
		}
	}
#endif

#ifdef CONFIG_GPIO_EXPORT
	gpio_export_init();
	gpio_unexport_init();
#endif

}

#endif							/* CONFIG_GPIO */
