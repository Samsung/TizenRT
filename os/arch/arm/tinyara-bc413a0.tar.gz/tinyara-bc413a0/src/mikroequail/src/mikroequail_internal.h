/****************************************************************************************************
 * arch/arm/src/mikroequail/src/mikroequail_internal.h
 *
 *   Copyright (C) 2011-2012 Gregory Nutt. All rights reserved.
 *   Authors: Gregory Nutt <gnutt@nuttx.org>
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name NuttX nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************************************/

#ifndef __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_INTERNAL_H
#define __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_INTERNAL_H

/****************************************************************************************************
 * Included Files
 ****************************************************************************************************/

#include <tinyara/config.h>
#include <tinyara/compiler.h>
#include <stdint.h>

/****************************************************************************************************
 * Definitions
 ****************************************************************************************************/
/* Configuration ************************************************************************************/
/* How many SPI modules does this chip support? */

#if STM32_NSPI < 1
#undef CONFIG_STM32_SPI1
#undef CONFIG_STM32_SPI2
#undef CONFIG_STM32_SPI3
#elif STM32_NSPI < 2
#undef CONFIG_STM32_SPI2
#undef CONFIG_STM32_SPI3
#elif STM32_NSPI < 3
#undef CONFIG_STM32_SPI3
#endif

/* Board LEDs Pin Mapping*/

#define GPIO_LED1       (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_50MHz|\
						 GPIO_OUTPUT_CLEAR|GPIO_PORTE|GPIO_PIN15)
#define GPIO_LED2       (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_50MHz|\
						 GPIO_OUTPUT_CLEAR|GPIO_PORTE|GPIO_PIN10)
#define GPIO_LED3       (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_50MHz|\
						 GPIO_OUTPUT_CLEAR|GPIO_PORTC|GPIO_PIN3)

#if defined(CONFIG_BOARD_SOCKETS_EN)
/***********************************************************************
* MIKROE QUAIL BOARD SOCKET INTERFACE TYPE
***********************************************************************/

#define IF_TYPE_NONE 0
#define IF_TYPE_AN 1
#define IF_TYPE_I2C 2
#define IF_TYPE_PWM 3
#define IF_TYPE_SERIAL 4
#define IF_TYPE_SPI 5

/***********************************************************************
* MIKROE QUAIL BOARD SOCKET DEVICE TYPE
*
* Any change in device type sequenceshould be refelected in Kconfig
* file as well to makesure proper pin is selected for click boards.
***********************************************************************/

#define DEV_TYPE_DISPLAY 1
#define DEV_TYPE_ETHERNET 2
#define DEV_TYPE_SERIALNORFLASH 3
#define DEV_TYPE_ZIGBEE 4
#define DEV_TYPE_WIFI 5

/***********************************************************************
*                MIKROE QUAIL BOARD SOCKET MAP INFO
***********************************************************************/

/**** Mikro Bus-socket#1 bus interface protocol is selected in defconfig
 * file based on Mikro-Click board bus interface type *****************/

/***********************************************************************
 *                      SOCKET#1 PIN MAP INFO
 ***********************************************************************
 *  SNO     SOCKET PIN          FUNCTION        MCU PIN ASSIGNMENT
 ***********************************************************************
 *  1           AN              ADC12_IN6               PA6
 *  2           RST             GPIO                    PA2
 *  3           CS              GPIO                    PA3
 *  4           SCK             SPI1_SCK                PB3
 *  5           MISO            SPI1_SO                 PB4
 *  6           MOSI            SPI1_SI                 PB5
 *  7           VCC 3.3         NA                      NA
 *  8           GND             NA                      NA
 *  9           GND             NA                      NA
 * 10           VCC 5           NA                      NA
 * 11           SDA             I2C1_SDA                PB7
 * 12           SCL             I2C1_SCL                PB6
 * 13           TX              USART3_TX               PD8
 * 14           RX              USART3_RX               PD9
 * 15           INT             GPIO                    PA1
 * 16           PWM             TIM1_CH1                PE9
 *
 * ********************************************************************/
/*If Interface is used as SPI*/
#if (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SPI)

#if defined(CONFIG_STM32_SPI1)
/*Mikro Bus-socket#1- SPI is mapped to STM32F427 MCU's SPI-1*/
#define GPIO_SPI1_MISO GPIO_SPI1_MISO_2	/*PB4 */
#define GPIO_SPI1_MOSI GPIO_SPI1_MOSI_2	/*PB5 */
#define GPIO_SPI1_SCK  GPIO_SPI1_SCK_2	/*PB3 */
#endif
#if (CONFIG_BOARD_SOCKET1_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60))
#define CONFIG_BOARD_SOCKET_DEV_ETHERNET
#define ENC28J60_BOARD_SPI_PORTNO      1	/* On SPI1 */
#define GPIO_ENC28J60_INTR     (GPIO_INPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTA | GPIO_PIN1)	/*PA1 */
#define GPIO_ENC28J60_RESET    (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTA | GPIO_PIN2)	/*PA2 */
#define GPIO_ENC28J60_CS       (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTA | GPIO_PIN3)	/*PA3 */
#endif							/*(CONFIG_BOARD_SOCKET1_DEV == DEV_TYPE_ETHERNET ) && (defined(CONFIG_ENC28J60)) */

/*If Interface is used as Analog Input*/
#elif (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_AN)
#error Configure Mikro-Click Board	/*PA6 */

/*If Interface is used as I2C*/
#elif (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_I2C)
#error Configure Mikro-Click Board	/*PB6&7 */

/*If Interface is used as SERIAL*/
#elif (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SERIAL)
/* USART3:*/
#define GPIO_USART3_RX GPIO_USART3_RX_3	/*PD9 */
#define GPIO_USART3_TX GPIO_USART3_TX_3	/*PD8 */

/*If Interface is used as PWM*/
#elif (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_PWM)
#define GPIO_TIM1_CH1OUT GPIO_TIM1_CH1OUT_2	/*PE9 */
/*If Interface is None*/
#elif (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_NONE)
/*Place holder*/
#else
#error Not supported Socket interface.
#endif							/*CONFIG_BOARD_SOCKET1_IF */

/**** Mikro Bus-socket#2 bus interface protocol is selected in defconfig
 * file based on Mikro-Click board bus interface type *****************/

/***********************************************************************
 *                     SOCKET#2 PIN MAP INFO
 ***********************************************************************
 *  SNO   SOCKET PIN      FUNCTION      MCU PIN ASSIGNMENT
 * *********************************************************************
 *   1      AN           ADC12_IN4               PA4
 *   2      RST          GPIO                    PE1
 *   3      CS           GPIO                    PE0
 *   4      SCK          SPI1_SCK                PB3
 *   5      MISO         SPI1_SO                 PB4
 *   6      MOSI         SPI1_SI                 PB5
 *   7      VCC 3.3      NA                      NA
 *   8      GND          NA                      NA
 *   9      GND          NA                      NA
 *  10      VCC 5        NA                      NA
 *  11      SDA          I2C1_SDA                PB7
 *  12      SCL          I2C1_SCL                PB6
 *  13      TX           USART2_TX               PD5
 *  14      RX           USART2_RX               PD6
 *  15      INT          GPIO                    PB9
 *  16      PWM          TIM4_CH4                PD15
 *
 * *********************************************************************/

/*If Interface is used as SPI*/
#if (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)

#if defined(CONFIG_STM32_SPI1)
/*Mikro Bus-socket#2- SPI is mapped to STM32F427 MCU's SPI-1*/
#define GPIO_SPI1_MISO GPIO_SPI1_MISO_2	/*PB4 */
#define GPIO_SPI1_MOSI GPIO_SPI1_MOSI_2	/*PB5 */
#define GPIO_SPI1_SCK  GPIO_SPI1_SCK_2	/*PB3 */
#endif							/*CONFIG_STM32_SPI1 */

#if (CONFIG_BOARD_SOCKET2_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60))
#define CONFIG_BOARD_SOCKET_DEV_ETHERNET
#define ENC28J60_BOARD_SPI_PORTNO      1	/* On SPI1 */
#define GPIO_ENC28J60_INTR     (GPIO_INPUT | GPIO_SPEED_50MHz| \
								GPIO_PORTB | GPIO_PIN9)	/*PB9 */
#define GPIO_ENC28J60_RESET    (GPIO_OUTPUT | GPIO_SPEED_50MHz| \
								GPIO_PORTE | GPIO_PIN1)	/*PE1 */
#define GPIO_ENC28J60_CS       (GPIO_OUTPUT | GPIO_SPEED_50MHz| \
								GPIO_PORTE | GPIO_PIN0)	/*PE0 */
#endif							/*(CONFIG_BOARD_SOCKET2_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60)) */

/*If Interface is used as Analog Input*/
#elif (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_AN)
#error Configure Mikro-Click Board

/*If Interface is used as I2C*/
#elif (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_I2C)
#error Configure Mikro-Click Board

/*If Interface is used as SERIAL*/
#elif (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SERIAL)
/* USART2:*/
#define GPIO_USART2_RX GPIO_USART2_RX_2	/*PD6 */
#define GPIO_USART2_TX GPIO_USART2_TX_2	/*PD5 */

/*If Interface is used as PWM*/
#elif (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_PWM)
#define GPIO_TIM4_CH4OUT GPIO_TIM4_CH4OUT_2	/*PD15 */

/*If Interface is None*/
#elif (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_NONE)
/*Place holder*/
#else
#error Not supported Socket interface.
#endif							/*CONFIG_BOARD_SOCKET2_IF */

/**** Mikro Bus-socket#3 bus interface protocol is selected in defconfig
 * file based on Mikro-Click board bus interface type *****************/

/***********************************************************************
 *                   SOCKET#3 PIN MAP INFO
 ***********************************************************************
 *  SNO  SOCKET PIN      FUNCTION       MCU PIN ASSIGNMENT
 * *********************************************************************
 *   1     AN            ADC12_IN7               PA7
 *   2     RST           GPIO                    PD12
 *   3     CS            GPIO                    PD11
 *   4     SCK           SPI3_SCK                PC10
 *   5     MISO          SPI3_SO                 PC11
 *   6     MOSI          SPI3_SI                 PC12
 *   7     VCC 3.3       NA                      NA
 *   8     GND           NA                      NA
 *   9     GND           NA                      NA
 *  10     VCC 5         NA                      NA
 *  11     SDA           I2C1_SDA                PB7
 *  12     SCL           I2C1_SCL                PB6
 *  13     TX            USART6_TX               PC6
 *  14     RX            USART6_RX               PC7
 *  15     INT           GPIO                    PC8
 *  16     PWM           TIM4_CH2                PD13
 *
 * *********************************************************************/

/*If Interface is used as SPI*/
#if (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)

#if defined(CONFIG_STM32_SPI3)
/*Mikro Bus-socket#3- SPI is mapped to STM32F427 MCU's SPI-1*/
/*SPI3:*/
#define GPIO_SPI3_MISO GPIO_SPI3_MISO_2	/*PC11 */
#define GPIO_SPI3_MOSI GPIO_SPI3_MOSI_2	/*PC12 */
#define GPIO_SPI3_SCK  GPIO_SPI3_SCK_2	/*PC10 */
#endif							/*(CONFIG_STM32_SPI3) */

#if (CONFIG_BOARD_SOCKET3_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60))
#define CONFIG_BOARD_SOCKET_DEV_ETHERNET
#define ENC28J60_BOARD_SPI_PORTNO      3	/* On SPI3 */
#define GPIO_ENC28J60_INTR     (GPIO_INPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTC | GPIO_PIN8)	/*PC8 */
#define GPIO_ENC28J60_RESET    (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTD | GPIO_PIN12)	/*PD12 */
#define GPIO_ENC28J60_CS       (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTD | GPIO_PIN11)	/*PD11 */
#endif							/*(CONFIG_BOARD_SOCKET3_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60)) */

#if (CONFIG_BOARD_SOCKET3_DEV == DEV_TYPE_SERIALNORFLASH) && (defined(CONFIG_EN25F80_FLASH))
#define CONFIG_BOARD_SOCKET_DEV_FLASH
#define EN25F80_BOARD_SPI_PORTNO      3	/* On SPI3 */
#define GPIO_EN25F80_CS        (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTD | GPIO_PIN11)	/*PD11 */

#endif							/*(CONFIG_BOARD_SOCKET1_DEV == DEV_TYPE_SERIALNORFLASH) && (defined(CONFIG_EN25Q80B_FLASH)) */

/*If Interface is used as Analog Input*/
#elif (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_AN)
#error Configure Mikro-Click Board

/*If Interface is used as I2C*/
#elif (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_I2C)
#error Configure Mikro-Click Board

/*If Interface is used as SERIAL*/
#elif (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SERIAL)
/* USART6:*/
#define GPIO_USART6_RX GPIO_USART6_RX_1	/*PC7 */
#define GPIO_USART6_TX GPIO_USART6_TX_1	/*PC6 */

/*If Interface is used as PWM*/
#elif (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_PWM)
#define GPIO_TIM4_CH2OUT GPIO_TIM4_CH2OUT_2	/*PD13 */

/*If Interface is None*/
#elif (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_NONE)
/*Place holder*/
#else
#error Not supported Socket interface.
#endif							/*CONFIG_BOARD_SOCKET3_IF */

/***********************************************************************
 *                    SOCKET#4 PIN MAP INFO
 ***********************************************************************
 *  SNO  SOCKET PIN     FUNCTION         MCU PIN ASSIGNMENT
 * *********************************************************************
 *   1       AN         ADC12_IN5                PA5
 *   2       RST        GPIO                     PD0
 *   3       CS         GPIO                     PD1
 *   4       SCK        SPI1_SCK                 PC10
 *   5       MISO       SPI1_SO                  PC11
 *   6       MOSI       SPI1_SI                  PC12
 *   7       VCC 3.3    NA                       NA
 *   8       GND        NA                       NA
 *   9       GND        NA                       NA
 *  10       VCC 5      NA                       NA
 *  11       SDA        I2C_SDA                  PB7
 *  12       SCL        I2C_SCL                  PB6
 *  13       TX         USART1_TX                PA9
 *  14       RX         USART1_RX                PA10
 *  15       INT        GPIO                     PA14
 *  16       PWM        TIM1_CH3                 PD14
 *
 * *********************************************************************/

/**** Mikro Bus-socket#4 bus interface protocol is selected in defconfig
 * file based on Mikro-Click board bus interface type *****************/

/*If Interface is used as SPI*/
#if (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
/*Mikro Bus-socket#4- SPI is mapped to STM32F427 MCU's SPI-3*/
#if defined(CONFIG_STM32_SPI3)
/*Mikro Bus-socket#3- SPI is mapped to STM32F427 MCU's SPI-1*/
/*SPI3:*/
#define GPIO_SPI3_MISO GPIO_SPI3_MISO_2	/*PC11 */
#define GPIO_SPI3_MOSI GPIO_SPI3_MOSI_2	/*PC12 */
#define GPIO_SPI3_SCK  GPIO_SPI3_SCK_2	/*PC10 */
#endif							/*(CONFIG_STM32_SPI3) */

#if (CONFIG_BOARD_SOCKET4_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60))
#define CONFIG_BOARD_SOCKET_DEV_ETHERNET
#define ENC28J60_BOARD_SPI_PORTNO      3	/* On SPI3 */
#define GPIO_ENC28J60_INTR     (GPIO_INPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTA | GPIO_PIN14)	/*PA14 */
#define GPIO_ENC28J60_RESET    (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTD | GPIO_PIN0)	/*PD0 */
#define GPIO_ENC28J60_CS       (GPIO_OUTPUT | GPIO_SPEED_50MHz | \
								GPIO_PORTD | GPIO_PIN1)	/*PD1 */
#endif							/*(CONFIG_BOARD_SOCKET4_DEV == DEV_TYPE_ETHERNET) && (defined(CONFIG_ENC28J60)) */

/*If Interface is used as Analog Input*/
#elif (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_AN)
#error Configure Mikro-Click Board
/*If Interface is used as I2C*/
#elif (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_I2C)
#error Configure Mikro-Click Board
/*If Interface is used as SERIAL*/
#elif (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SERIAL)
/* USART1:*/
#define GPIO_USART1_RX GPIO_USART1_RX_1	/*PA10 */
#define GPIO_USART1_TX GPIO_USART1_TX_1	/*PA9 */

/*If Interface is used as PWM*/
#elif (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_PWM)
#define GPIO_TIM4_CH3OUT GPIO_TIM4_CH3OUT_2	/*PD14 */
/*If Interface is None*/
#elif (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_NONE)
/*Place holder*/
#else
#error Not supported Socket interface.
#endif							/*CONFIG_BOARD_SOCKET4_IF */

#endif							/*CONFIG_BOARD_SOCKETS_EN */

/****************************************************************************************************
 * Public Types
 ****************************************************************************************************/

/****************************************************************************************************
 * Public data
 ****************************************************************************************************/

#ifndef __ASSEMBLY__

/****************************************************************************************************
 * Public Functions
 ****************************************************************************************************/

/****************************************************************************************************
 * Name: stm32_spiinitialize
 *
 * Description:
 *   Called to configure SPI chip select GPIO pins for the Mikroe Quail board.
 *
 ****************************************************************************************************/
#if defined(CONFIG_STM32_SPI1) || defined(CONFIG_STM32_SPI3)
void weak_function stm32_spiinitialize(void);
#endif
/****************************************************************************************************
 * Name: stm32_usbhost_initialize
 *
 * Description:
 *   Called at application startup time to initialize the USB host functionality. This function will
 *   start a thread that will monitor for device connection/disconnection events.
 *
 ****************************************************************************************************/

#if defined(CONFIG_STM32_OTGFS) && defined(CONFIG_USBHOST)
int stm32_usbhost_initialize(void);
#endif

/****************************************************************************************************
 * Name: stm32_ledpminitialize
 *
 * Description:
 *   Enable logic to use the LEDs on the Mikroe Quail to support power management testing
 *
 ****************************************************************************************************/

#ifdef CONFIG_PM
void stm32_ledpminitialize(void);
#endif

/****************************************************************************************************
 * Name: stm32_pmbuttons
 *
 * Description:
 *   Configure the user button of the Mikroe Quail board as EXTI,
 *   so it is able to wakeup the MCU from the PM_STANDBY mode
 *
 ****************************************************************************************************/

#if defined(CONFIG_PM) && defined(CONFIG_ARCH_IDLE_CUSTOM) && defined(CONFIG_PM_BUTTONS)
void stm32_pmbuttons(void);
#endif

/****************************************************************************************************
 * Name: up_pwminitialize
 *
 * Description:
 *   Called at during board_initialize time to initialize board specific PWM channels
 *
 ****************************************************************************************************/

#if defined(CONFIG_PWM)
void up_pwminitialize(void);
#endif

#endif							/* __ASSEMBLY__ */
#endif							/* __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_INTERNAL_H */
