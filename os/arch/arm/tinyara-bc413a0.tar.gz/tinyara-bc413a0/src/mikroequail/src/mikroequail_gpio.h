/****************************************************************************
 *
 * Copyright 2016 Samsung Electronics All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 ****************************************************************************/

#ifndef __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_GPIO_H
#define __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_GPIO_H

/******************************************************************************
 * Included Files
 *****************************************************************************/

#include <tinyara/config.h>
#include <tinyara/gpio.h>

#ifdef CONFIG_GPIO
/************************************************************************************
 * Pre-Processor Declarations
 ************************************************************************************/

enum mikroequail_board_gpio {
	BOARD_GPIOS_NUMBER = -1,
	/*PORT A */
#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET1_IF == IF_TYPE_SPI)
	GPIO_PORTA_PIN1,
	GPIO_PORTA_PIN2,
	GPIO_PORTA_PIN3,
#endif
	GPIO_PORTA_PIN4,
	GPIO_PORTA_PIN5,
	GPIO_PORTA_PIN6,
	GPIO_PORTA_PIN7,
#if !defined(CONFIG_STM32_USART1)
	GPIO_PORTA_PIN9,
	GPIO_PORTA_PIN10,
#endif
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
	GPIO_PORTA_PIN14,
#endif
	/*PORT B */
#if !defined(CONFIG_STM32_SPI1)
	GPIO_PORTB_PIN3,
	GPIO_PORTB_PIN4,
	GPIO_PORTB_PIN5,
#endif
#if !defined(CONFIG_STM32_I2C1)
	GPIO_PORTB_PIN6,
	GPIO_PORTB_PIN7,
#endif
#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
	GPIO_PORTB_PIN9,
#endif
	/*PORT C */
#if !defined(CONFIG_STM32_USART6)
	GPIO_PORTC_PIN6,
	GPIO_PORTC_PIN7,
#endif
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
	GPIO_PORTC_PIN8,
#endif
#if !defined(CONFIG_STM32_SPI3)
	GPIO_PORTC_PIN10,
	GPIO_PORTC_PIN11,
	GPIO_PORTC_PIN12,
#endif
	/*PORT D */
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET4_IF == IF_TYPE_SPI)
	GPIO_PORTD_PIN0,
	GPIO_PORTD_PIN1,
#endif
#if !defined(CONFIG_STM32_USART2)
	GPIO_PORTD_PIN5,
	GPIO_PORTD_PIN6,
#endif
#if !defined(CONFIG_STM32_USART3)
	GPIO_PORTD_PIN8,
	GPIO_PORTD_PIN9,
#endif
#if (!defined(CONFIG_STM32_SPI3)) && (CONFIG_BOARD_SOCKET3_IF == IF_TYPE_SPI)
	GPIO_PORTD_PIN11,
	GPIO_PORTD_PIN12,
#endif
	GPIO_PORTD_PIN13,
	GPIO_PORTD_PIN14,
#if !(CONFIG_STM32_TIM4_CHANNEL == 4)
	GPIO_PORTD_PIN15,
#endif
	/*PORT E */
#if (!defined(CONFIG_STM32_SPI1)) && (CONFIG_BOARD_SOCKET2_IF == IF_TYPE_SPI)
	GPIO_PORTE_PIN0,
	GPIO_PORTE_PIN1,
#endif
#if !(CONFIG_STM32_TIM1_CHANNEL == 1)
	GPIO_PORTE_PIN9,
#endif
	BOARD_GPIOS_COUNT
};

#define MIKROE_QUAIL_BOARD_GPIOS_COUNT BOARD_GPIOS_COUNT
#define GPIO_INT_EVENT_STATUS_NONE 0x0
#define GPIO_INT_SET     0x1
#define GPIO_EVENT_SET     0x2
#define GPIO_INT_EVENT_SET 0x3
#define GPIO_PIN_CFG_NONE  0x0

/****************************************************************************
 * Public Function Prototypes
 ****************************************************************************/

/*Function to initialize board GPIO in vfs*/
void up_gpioinitialize(void);

/*Function to remove board GPIO entry in vfs*/
int up_destroy_gpio(int32_t idx);

#endif							/* CONFIG_GPIO */
#endif							/* __ARCH_ARM_SRC_MIKROEQUAIL_SRC_MIKOEQUAIL_GPIO_H */
